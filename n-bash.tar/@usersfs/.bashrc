#!/usr/bin/bash
export PS1="\n“\w”\n[$(whoami)]: "

# Adding BMODS to PATH
PATH=$PATH:~/.bmods/

# Source global definitions
if [ -f /etc/bashrc ]; then
	. /etc/bashrc
fi

# User specific environment
if ! [[ "$PATH" =~ "$HOME/.local/bin:$HOME/bin:" ]]
then
    PATH="$HOME/.local/bin:$HOME/bin:$PATH"
fi
export PATH
unset rc

# Some environment candy
alias s="sudo"
alias c="clear"
alias r="su"
alias q="exit 0"
alias prt="echo -e"
alias mkd="mkdir"
alias elf="chmod 755"
alias dl="wget -q"
alias d0="/dev/0"
alias o="systemctl suspend"
alias off="systemctl poweroff"

# Try creating bmods dir
[[ ! -e ~/.bmods ]] && mkdir ~/.bmods/
[[ ! -d ~/.bmods/.disabled ]] && mkdir ~/.bmods/.disabled/

# Ignore the lines below when the graphical environment loads
[[ ! $- != *i* ]] && return

# Load bmods
for mod in $(ls -a ~/.bmods/)
do
	chmod +x ~/.bmods/$mod
	[[ $mod = "+"* || $mod = ".+"* ]] && source ~/.bmods/$mod
done
mods=($(ls ~/.bmods/))
echo -e "${mods[@]}"

