Before creating a new issue, please follow each step in the TROUBLESHOOTING section
of the main README.

**Please ensure you paste the output from the following command whenever you raise any issue**:
```
libinput-gestures -l
```
