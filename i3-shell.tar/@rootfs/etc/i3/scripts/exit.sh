pkill -f /bin/sh; pkill nitrogen; pkill blueman; pkill nm-applet; pkill nm-tray; pkill pasystray; pkill org.kde.xwaylandvideobridge; pkill dunst ; pkill libinput-gestures ; i3-msg exit
