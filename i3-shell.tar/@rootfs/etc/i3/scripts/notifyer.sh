run(){
      dunst -config /etc/i3/configs/dunstrc
      [ $? != 0 ] && run
}
run
