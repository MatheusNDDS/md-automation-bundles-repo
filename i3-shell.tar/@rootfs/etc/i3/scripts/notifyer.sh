run(){
      dunst -config /etc/i3/dunstrc
      [ $? != 0 ] && run
}
run
