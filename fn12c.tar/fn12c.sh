#!/usr/bin/bash
java -jar /etc/fn12c/finanx.jar &
