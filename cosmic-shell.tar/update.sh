rm -rf '@usersfs/.config/cosmic/'
cp -r ~/.config/cosmic/ '@usersfs/.config/cosmic/'