to_ignore=" com.system76.CosmicBackground "
for dir in $(ls \@usersfs/.config/cosmic/)
do 
   echo $dir
   if [[ $to_ignore != *" $dir "* ]]
   then
      rm -rf \@usersfs/.config/cosmic/$dir
      cp -r ~/.config/cosmic/$dir \@usersfs/.config/cosmic/
   else
      echo "--- $dir ignored ---"
   fi
done