rm -rf '@usersfs/.config/cosmic/'
cp -r ~/.config/cosmic/ '@usersfs/.config/cosmic/'
rm -rf '@usersfs/.config/cosmic/com.system76.CosmicFiles'