#!/usr/bin/env sh
#
# name: Bloquear
# icon: locked
# description: Bloqueia a tela
# keywords: bloquear tela

set -eu

xdg-screensaver lock
