#!/usr/bin/env sh
#
# name: Bloquear
# icon: locked
# description: Bloqueia a tela
# keywords: bloquear tela

source /usr/lib/pop-launcher/scripts/session/session-lock.sh