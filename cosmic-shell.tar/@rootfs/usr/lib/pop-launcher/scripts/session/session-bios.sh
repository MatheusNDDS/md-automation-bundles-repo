#!/usr/bin/env sh
#
# name: Entrar na BIOS
# icon: system-restart
# description: reinicia para a BIOS
# keywords: bios uefi reboot restart reiniciar rebootar 

source /usr/lib/pop-launcher/scripts/session/session-bios.sh
