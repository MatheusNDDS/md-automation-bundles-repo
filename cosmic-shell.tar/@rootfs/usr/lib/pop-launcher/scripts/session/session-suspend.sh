#!/usr/bin/env sh
#
# name: Suspender
# icon: system-suspend
# description: Suspende o sistema
# keywords: suspender suspend sleep

source /usr/lib/pop-launcher/scripts/session/session-suspend.sh