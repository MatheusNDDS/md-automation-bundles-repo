#!/usr/bin/env sh
#
# name: Reiniciar
# icon: system-restart
# description: Reinicia o sistema
# keywords: reiniciar power reboot restart

source /usr/lib/pop-launcher/scripts/session/session-reboot.sh