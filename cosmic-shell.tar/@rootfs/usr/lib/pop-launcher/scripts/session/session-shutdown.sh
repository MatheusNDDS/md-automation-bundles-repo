#!/usr/bin/env sh
#
# name: Desligar
# icon: system-shutdown
# description: Encerra o sistema
# keywords: desligar encerrar power off shutdown poweroff

source /usr/lib/pop-launcher/scripts/session/session-shutdown.sh