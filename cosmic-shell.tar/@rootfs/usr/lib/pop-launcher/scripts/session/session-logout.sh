#!/usr/bin/env sh
#
# name: Sair
# icon: system-log-out
# description: Encerra a sessão ativa
# keywords: sair sessão encerrar log out logout
 source /usr/lib/pop-launcher/scripts/session/session-logout.sh