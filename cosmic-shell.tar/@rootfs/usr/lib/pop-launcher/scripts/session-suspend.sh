#!/usr/bin/env sh
#
# name: Suspender
# icon: system-suspend
# description: Suspende o sistema
# keywords: suspender suspend sleep

set -eu

systemctl suspend
