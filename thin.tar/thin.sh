#!/usr/bin/bash
source /etc/bmn/init
thin_a=($*)

#Base Data
name=thin
bmr_db=~/.thindb

#Database configuration
if [ ! -f $bmr_db ]
then
	-mk $bmr_db
	#Theme
	-srg -d @thin_c 'plasma-apply-colorscheme'
	-srg -d @thin_d 'BreezeBlacker'
	-srg -d @thin_l 'BreezeLight'
	#Wallpaper
	-srg -d @thin_wpc 'plasma-apply-wallpaperimage'
	-srg -d @thin_2wpc ''
	-srg -d @thin_wpd '/etc/thin/thin_dark_wallpaper.jpg'
	-srg -d @thin_wpl '/etc/thin/thin_light_wallpaper.jpg'
fi

#Common Data
theme_cmd="$(-gd @thin_c)"
light_theme="$(-gd @thin_l)"
dark_theme="$(-gd @thin_d)"
wp_cmd="$(-gd @thin_wpc)"
wp_cmd2="$(-gd @thin_2wpc)"
wp_light="$(-gd @thin_wpl)"
wp_dark="$(-gd @thin_wpd)"
vd="$(-gd @nde_vdesktop)"
color="$(bmr -gd db=$pdir/.globaldb @nde_color_main)"
#Program
case $1 in
		-d|--dark)
			$theme_cmd "$dark_theme"
			$wp_cmd "$wp_dark" &
			[ ! -z "$wp_cmd2" ] && $wp_cmd2 "$wp_dark" &
			for i in 1 2 ; do plasma-apply-colorscheme -a "$color" ; done &
			-prt @thin_wpd @thin_d > ~/.thinrc
		;;
		-l|--light)
			$theme_cmd "$light_theme"
			$wp_cmd "$wp_light" &
			[ ! -z "$wp_cmd2" ] && $wp_cmd2 "$wp_light" &
			for i in 1 2 ; do plasma-apply-colorscheme -a "$color" ; done &
			-prt @thin_wpl @thin_l > ~/.thinrc
		;;
		-r|--restore)
			last_theme=($([ -f ~/.thinrc ] && cat ~/.thinrc))
			[ -z "$last_theme" ] && last_theme=(@thin_wpl @thin_l) && exec thin -r -wp -th &
			for arg in ${thin_a[@]:1}
			do
				case $arg in
					-wp|--wallpaper)
						$wp_cmd "$(-gd ${last_theme[0]})" &
						[ ! -z "$wp_cmd2" ] && $wp_cmd2 "$(-gd ${last_theme[0]})" &
					;;
					-th|--theme)
 						$theme_cmd "$(-gd ${last_theme[1]})"
						for i in 1 2 ; do plasma-apply-colorscheme -a "$color" ; done
					;;
				esac
			done
		;;
		-stc|--set-theme-command)
			-srg @thin_wpc ${thin_a[*]:1}
			-out -s $name "Comando de Wallpaper definido para “${thin_a[*]:1}”"
		;;
		-swce|--set-theme-command-extra)
			-srg @thin_2wpc ${thin_a[*]:1}
			-out -s $name "Comando de Wallpaper definido para “${thin_a[*]:1}”"
		;;
		-swc|--set-wallpaper-command)
			-srg @thin_c ${thin_a[*]:1}
			-out -s $name "Comando de tema definido para “${thin_a[*]:1}”"
		;;
		-sd|--set-dark)
			-srg @thin_d ${thin_a[*]:1}
			-out -s $name "Tema escuro definido para “${thin_a[*]:1}”"
		;;
		-sl|--set-light)
			-srg @thin_l ${thin_a[*]:1}
			-out -s $name "Tema claro definido para “${thin_a[*]:1}”"
		;;
		-sdw|--set-dark-wallpaper)
			-srg @thin_wpd ${thin_a[*]:1}
			-out -s $name "Papel de parede escuro definido para “${thin_a[*]:1}”"
		;;
		-slw|--set-light-wallpaper)
			-srg @thin_wpl ${thin_a[*]:1}
			-out -s $name "Papel de parede claro definido para “${thin_a[*]:1}”"
		;;
		-s*)
			thin -r -wp -th
		;;
		-h|--help)
			-prt '[Manual]\n -d, --dark  : Enable dark theme\n -l, --light : Enble light theme\n -stc, --set-command : Change the theme command.theme\n -swc, --set-wallpaper-command : Change the wallpaper command.\n -swce, --set-wallpaper-command-extra : Change the extra wallpaper command.\n -sd, --set-dark : Change the dark theme.\n -sl, --set-light : Chnage the light theme.\n -sdw, --set-dark-wallpaper : Change the dark theme Wallpaper.\n -slw, --set-dark : Change the light wallpaper theme.\n -r, --restore : Restore previous theme and wallpaper, use “-wp” and “-th” before to restore any.\n -h , --help : Print help text.'
		;;
esac
