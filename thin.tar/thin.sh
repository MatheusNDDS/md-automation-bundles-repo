#!/usr/bin/bash
source /etc/bmn/init
thin_a=($*)

#Base Data
name=thin
bmr_db=~/.thindb

#Database configuration
if [ ! -f $bmr_db ]
then
	$mk $log
	#Theme
	bmr -srg -d @thin_c 'plasma-apply-colorscheme'
	bmr -srg -d @thin_d 'BreezeBlacker'
	bmr -srg -d @thin_l 'BreezeLight'
	#Wallpaper
	bmr -srg -d @thin_wpc 'plasma-apply-wallpaperimage'
	bmr -srg -d @thin_2wpc ''
	bmr -srg -d @thin_wpd '/etc/thin/thin_dark_wallpaper.jpg'
	bmr -srg -d @thin_wpl '/etc/thin/thin_light_wallpaper.jpg'
fi

#Common Data
theme_cmd="$(bmr -gd @thin_c)"
light_theme="$(bmr -gd @thin_l)"
dark_theme="$(bmr -gd @thin_d)"
wp_cmd="$(bmr -gd @thin_wpc)"
wp_cmd2="$(bmr -gd @thin_2wpc)"
wp_light="$(bmr -gd @thin_wpl)"
wp_dark="$(bmr -gd @thin_wpd)"

#Program
case $1 in
		-d|--dark)
			$theme_cmd "$dark_theme" &
			$wp_cmd "$wp_dark" &
			[ ! -z "$wp_cmd2" ] && $wp_cmd2 "$wp_dark" &
			$prt @thin_wpd @thin_d > .thinrc
		;;
		-l|--light)
			$theme_cmd "$light_theme" &
			$wp_cmd "$wp_light" &
			[ ! -z "$wp_cmd2" ] && $wp_cmd2 "$wp_light" &
			$prt @thin_wpl @thin_l > .thinrc
		;;
		-r|--restore)
			last_theme=($([ -f ~/.thinrc ] && cat ~/.thinrc))
			[ -z "$last_theme" ] && last_theme=(@thin_wpl @thin_l) && exec thin -r -wp -th &
			for arg in ${thin_a[@]:1}
			do
				case $arg in
					-wp|--wallpaper)
						$wp_cmd "$(bmr -gd ${last_theme[0]})" &
						[ ! -z "$wp_cmd2" ] && $wp_cmd2 "$(bmr -gd ${last_theme[0]})" &
					;;
					-th|--theme)
						$theme_cmd "$(bmr -rg ${last_theme[1]})" &
					;;
				esac
			done
		;;
		-stc|--set-theme-command)
			bmr -srg @thin_wpc ${thin_a[*]:1}
			output -s $name "Comando de Wallpaper definido para “${thin_a[*]:1}”"
		;;
		-swce|--set-theme-command-extra)
			bmr -srg @thin_2wpc ${thin_a[*]:1}
			output -s $name "Comando de Wallpaper definido para “${thin_a[*]:1}”"
		;;
		-swc|--set-wallpaper-command)
			bmr -srg @thin_c ${thin_a[*]:1}
			output -s $name "Comando de tema definido para “${thin_a[*]:1}”"
		;;
		-sd|--set-dark)
			bmr -srg @thin_d ${thin_a[*]:1}
			output -s $name "Tema escuro definido para “${thin_a[*]:1}”"
		;;
		-sl|--set-light)
			bmr -srg @thin_l ${thin_a[*]:1}
			output -s $name "Tema claro definido para “${thin_a[*]:1}”"
		;;
		-sdw|--set-dark-wallpaper)
			bmr -srg @thin_wpd ${thin_a[*]:1}
			output -s $name "Papel de parede escuro definido para “${thin_a[*]:1}”"
		;;
		-slw|--set-light-wallpaper)
			bmr -srg @thin_wpl ${thin_a[*]:1}
			output -s $name "Papel de parede claro definido para “${thin_a[*]:1}”"
		;;
		-s*)
			thin -r -wp -th
		;;
		-h|--help)
			$prt '[Manual]\n -d, --dark  : Enable dark theme\n -l, --light : Enble light theme\n -stc, --set-command : Change the theme command.theme\n -swc, --set-wallpaper-command : Change the wallpaper command.\n -swce, --set-wallpaper-command-extra : Change the extra wallpaper command.\n -sd, --set-dark : Change the dark theme.\n -sl, --set-light : Chnage the light theme.\n -sdw, --set-dark-wallpaper : Change the dark theme Wallpaper.\n -slw, --set-dark : Change the light wallpaper theme.\n --r, --restore : Restore previous theme and wallpaper, use “-wp” and “-th” to restore any.\n -h , --help : Print help text.'
		;;
esac
