#!/usr/bin/env bash
source /etc/bmn/init

#data
thin_a=($*)
theme_cmd="$(bl -gd @thn_c)"
light_theme="$(bl -gd @thn_l)"
dark_theme="$(bl -gd @thn_d)"
name=thin

#run
case $1 in
		-d|--dark)
			$theme_cmd "$dark_theme"
		;;
		-l|--light)
			$theme_cmd "$light_theme"
		;;
		-scmd|--set-command)
			btest -root ; $err_cmd
			bl -srg @thn_c ${thin_a[*]:1}
			output -s $name "Comando de tema definido para “${thin_a[*]:1}”"
		;;
		-sd|--set-dark)
			btest -root ; $err_cmd
			bl -srg @thn_d ${thin_a[*]:1}
			output -s $name "Tema escuro definido para “${thin_a[*]:1}”"
		;;
		-sl|--set-light)
			btest -root ; $err_cmd
			bl -srg @thn_l ${thin_a[*]:1}
			output -s $name "Tema claro definido para “${thin_a[*]:1}”"
		;;
		-h|--help)
			$prt '[Manual]\n -d, --dark  : Enable dark theme\n -l, --light : Enble light theme\n -scmd, --set-command : Change the theme command.\n -sd, --set-dark : Change the dark theme.\n -sl, --set-light : Chnage the light theme.\n -h , --help : Print help text.'
		;;
esac
