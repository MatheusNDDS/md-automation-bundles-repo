#!/usr/bin/bash
source /etc/bmn/init
thin_a=($*)

#Base Data
name=thin
log=~/.thindb

#Database configuration
if [ ! -f $log ]
then
	$smk $log
	#Theme
	bl -srg -d @thin_c 'plasma-apply-colorscheme'
	bl -srg -d @thin_d 'BreezeBlacker'
	bl -srg -d @thin_l 'BreezeLight'
	#Wallpaper
	bl -srg -d @thin_wpc 'plasma-apply-wallpaperimage'
	bl -srg -d @thin_2wpc ''
	bl -srg -d @thin_wpd '/etc/thin/thin_dark_wallpaper.jpg'
	bl -srg -d @thin_wpl '/etc/thin/thin_light_wallpaper.jpg'
fi

#Common Data
theme_cmd="$(bl -gd @thin_c)"
light_theme="$(bl -gd @thin_l)"
dark_theme="$(bl -gd @thin_d)"
wp_cmd="$(bl -gd @thin_wpc)"
wp_cmd2="$(bl -gd @thin_2wpc)"
wp_light="$(bl -gd @thin_wpl)"
wp_dark="$(bl -gd @thin_wpd)"

#Program
case $1 in
		-d|--dark)
			$theme_cmd "$dark_theme" &
			$wp_cmd "$wp_dark" &
			[ ! -z "$wp_cmd2" ] && $wp_cmd2 "$wp_dark" &
			$prt @thin_wpd @thin_d > .thinrc
		;;
		-l|--light)
			$theme_cmd "$light_theme" &
			$wp_cmd "$wp_light" &
			[ ! -z "$wp_cmd2" ] && $wp_cmd2 "$wp_light" &
			$prt @thin_wpl @thin_l > .thinrc
		;;
		-r|--restore)
			last_theme=($([ -f ~/.thinrc ] && cat ~/.thinrc))
			[ -z "$last_theme" ] && last_theme=(@thin_wpl @thin_l) && exec thin -r -wp -th &
			for arg in ${thin_a[@]:1}
			do
				case $arg in
					-wp|--wallpaper)
						$wp_cmd "$(bl -rd ${last_theme[0]})" &
						[ ! -z "$wp_cmd2" ] && $wp_cmd2 "$(bl -rd ${last_theme[0]})" &
					;;
					-th|--theme)
						$theme_cmd "$(bl -rd ${last_theme[1]})" &
					;;
				esac
			done
		;;
		-stc|--set-theme-command)
			bl -srg @thin_wpc ${thin_a[*]:1}
			output -s $name "Comando de Wallpaper definido para “${thin_a[*]:1}”"
		;;
		-swce|--set-theme-command-extra)
			bl -srg @thin_2wpc ${thin_a[*]:1}
			output -s $name "Comando de Wallpaper definido para “${thin_a[*]:1}”"
		;;
		-swc|--set-wallpaper-command)
			bl -srg @thin_c ${thin_a[*]:1}
			output -s $name "Comando de tema definido para “${thin_a[*]:1}”"
		;;
		-sd|--set-dark)
			bl -srg @thin_d ${thin_a[*]:1}
			output -s $name "Tema escuro definido para “${thin_a[*]:1}”"
		;;
		-sl|--set-light)
			bl -srg @thin_l ${thin_a[*]:1}
			output -s $name "Tema claro definido para “${thin_a[*]:1}”"
		;;
		-sdw|--set-dark-wallpaper)
			bl -srg @thin_wpd ${thin_a[*]:1}
			output -s $name "Papel de parede escuro definido para “${thin_a[*]:1}”"
		;;
		-slw|--set-light-wallpaper)
			bl -srg @thin_wpl ${thin_a[*]:1}
			output -s $name "Papel de parede claro definido para “${thin_a[*]:1}”"
		;;
		-h|--help)
			$prt '[Manual]\n -d, --dark  : Enable dark theme\n -l, --light : Enble light theme\n -stc, --set-command : Change the theme command.theme\n -swc, --set-wallpaper-command : Change the wallpaper command.\n -swce, --set-wallpaper-command-extra : Change the extra wallpaper command.\n -sd, --set-dark : Change the dark theme.\n -sl, --set-light : Chnage the light theme.\n --r, --restore : Restore previous theme and wallpaper, use “-wp” and “-th” to restore any.\n -h , --help : Print help text.'
		;;
esac
