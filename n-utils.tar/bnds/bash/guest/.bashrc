#!/usr/bin/bash
export PS1="\n“\w”\n[$(whoami)]: "
#export $(dbus-launch)

PATH=$PATH:~/.bmods/

# Source global definitions
if [ -f /etc/bashrc ]; then
	. /etc/bashrc
fi

# User specific environment
if ! [[ "$PATH" =~ "$HOME/.local/bin:$HOME/bin:" ]]
then
    PATH="$HOME/.local/bin:$HOME/bin:$PATH"
fi
export PATH

# Uncomment the following line if you don't like systemctl's auto-paging feature:
# export SYSTEMD_PAGER=

# User specific aliases and functions
if [ -d ~/.bashrc.d ]; then
	for rc in ~/.bashrc.d/*; do
		if [ -f "$rc" ]; then
			. "$rc"
		fi
	done
fi

unset rc

# Environment Setting #
export bnd_dev_dir="$HOME/Projetos/MD_Automation_Bundles"
alias l="exa"
alias s="sudo"
alias c="clear"
alias r="su"
alias q="exit 0"
alias prt="echo -e"
alias mkd="mkdir"
alias elf="chmod 755"
alias dl="wget -q"
alias d0="/dev/0"
alias tvw="s teamviewer --daemon start"
alias fm="mc -b"
alias rpi="ssh pi@192.168.1.23"
alias o="sudo systemctl suspend"
alias off="sudo systemctl poweroff"
alias bndrp="pastaAtual=$(pwd);cd $bnd_dev_dir; bp *;cd $pastaAtual"
alias bmr="s bmn -api bmr"
alias pma="bmn -api pma"
alias qs='ndm -rs ; exit 0'

#try creating bmods dir
if [ ! -e ~/.bmods ]
then
	mkdir ~/.bmods/
elif [ ! -d ~/.bmods/.disabled ]
then
	mkdir ~/.bmods/.disabled/
fi

#load bmods
for mod in $(ls -a ~/.bmods/)
do
	chmod +x ~/.bmods/$mod
	[[ $mod = "+"* || $mod = ".+"* ]] && source ~/.bmods/$mod
done
mods="$(ls ~/.bmods/)"
echo -e $mods

#set the virtual desktop environment
[[ -z $XDG_CURRENT_DESKTOP ]] && export XDG_CURRENT_DESKTOP=$(bmn -rd @nde_vdesktop) && n2
q
