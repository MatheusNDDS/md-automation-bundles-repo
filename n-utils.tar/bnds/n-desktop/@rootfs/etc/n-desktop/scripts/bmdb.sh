#!/usr/bin/env bash
prt="echo -e"
bkc=@
output(){
out_a=($*)
	test_args=(1 2 3 4)
	declare -A t
	[[ $1 = 0 ]] && t[0]="\033[01;36m-=/Automation Bundles Manager/=-\033[00m \n~ MatheusNDDS : https://github.com/MatheusNDDS\n"
	[[ $1 = 1 ]] && t[1]="\033[01;33m[Properties]\033[00m\n User: $u\n Home: $h\n PkgM: $pm\n Repo: $repo"
	[[ $1 = 2 ]] && t[2]="\033[01;33m[Commands]\033[00m
$(output -t "Bundles managment")
  --install -i : Install bundles from repository, use “-iu” to update $pm packages during installation.
  --lc-install -li : Install bundles from $file_format file path, use “-liu” to update $pm packages during installation.
  --dir-install -di : Install bundles from unpacked dir path, use “-diu” to update $pm packages during installation.
  --dowload -bdl : Download bundles from repository.
  --list-bnds -l : List or search for bundles in repo file.
  --repo-update -rU : Update repository release file, use this regularly.
  --clean -c : Clean invalid bundles residues.

$(output -t "Script tools")
  --$name-update -U : Update $name script from Repo source or local script.
  --list-config -lc : List all avaliable configurations.
  --read-config -rc : Read configuration data.
  --set-config -sc : Change a configuration value.
  --bnd-pack, -bp : Pack a bundle from a directory.
  --live-shell -sh : Run live shell for testing $name functions.
  --properties -p : Prints the user information that $name uses.

$(output -t "BMN Register commands")
 Use “db=yourdbfile” in second argument to change database file.
  -rl : Read a Line.
  -rd : Read a line data only.
  -rg : Register and alter a line or use other BMR functions.

\033[01;33m[Api Functions]\033[00m
 Some useful functions commands used in $name_upper that cam be acessible for every shell script language.
 Syntax: $name -api “function”.

\033[01m  output :\033[00m The function used to format text in $name_upper and Recipe Srcipts. Use “output -h” for help.
\033[01m  pma :\033[00m The Package Manager Abstractor, a simple and extensible program for abstract package management across some Linux distros.  Use “pma -h” for help.
\033[01m  bmr :\033[00m The $name_upper Register, provide a simple text based database. Use “bmr -h” for help.

 --help -h : Print help text."

	[[ $1 = 3 ]] && t[3]="bndp_a=(${bndp_a[*]})\nbndf=$bndf\nbnd_raw_name=$bnd_raw_name\nbnd_pre_name=(${bnd_pre_name[*]})\nbnd_name=$bnd_name\nbnd_pre_flags=(${bnd_pre_flags[*]})\nflags=(${bnd_flags[*]})"
	[[ $1 = '-h' ]] && t['-h']="$(output -T "$name_upper Output Formatter")\n\n$(output -t "Titles")\n -hT : High Normal.\n -ahT : High Alert.\n -shT : High Sucess.\n -ehT : High Error.\n -T : Low Title.\n\n$(output -t "Dialogs")\n -d : Normal.\n -l : List.\n -p : Process.\n -t : Task.\n -a : Alert.\n -s : Sucess.\n -e : Error."
	[[ $1 = '-p' ]] && t['-p']="\033[01;35m [$2]: -=- $([[ ! -z $3 ]] && $prt "$*" | sed "s/$1 $2//") -=-\033[00m" #Process
	[[ $1 = '-l' ]] && t['-l']="\033[01m $2: [ $($prt $([[ ! -z $3 ]] && $prt "$*" | sed "s/$1 $2//")|tr ' ' ', ') ]\033[00m " #List itens
	[[ $1 = '-hT' ]] &&  t['-hT']="\v\033[01;36m******** [ ${out_a[*]:1} ] ********\033[00m\v" #High Title
	[[ $1 = '-ahT' ]] &&  t['-ahT']="\v\033[01;33m******** // ${out_a[*]:1} // ********\033[00m\v" #Alert High Title
	[[ $1 = '-shT' ]] &&  t['-shT']="\v\033[01;32m******** ( ${out_a[*]:1} ) ********\033[00m\v" #Sucess High Title
	[[ $1 = '-ehT' ]] &&  t['-ehT']="\v\033[01;31m*#*#*#*# { $( echo "${out_a[*]:1}" | tr [:lower:] [:upper:]) } #*#*#*#*\033[00m\v" #Error High Title
	[[ $1 = '-bH' ]] &&  t['-bH']="\033[01;36m ### $([[ ! -z $3 ]] && $prt "$*" | sed "s/$1 $2//") ###\n ~ $2 ~\033[00m\n" #Bundle Header
	[[ $1 = '-T' ]] &&  t['-T']="\n\033[01;36m ## ${out_a[*]:1} ##\033[00m\n" #Title
	[[ $1 = '-t' ]] &&  t['-t']="\033[01m -- ${out_a[*]:1}\033[00m" #Subtitle
	[[ $1 = '-d' || $1 = '-qi' ]] &&  t['-d']="\033[01m [$2]: $([[ ! -z $3 ]] && $prt "$*" | sed "s/$1 $2//")\033[00m" #Dialog, bmr Data
	[[ $1 = '-e' || $1 = '-qi' ]] &&  t['-e']="\033[01;31m >> {$2}: $([[ ! -z $3 ]] && $prt "$*" | sed "s/$1 $2//") <<\033[00m" #Error Dialog
	[[ $1 = '-s' || $1 = '-qi' ]] &&  t['-s']="\033[01;32m ($2): $([[ ! -z $3 ]] && $prt "$*" | sed "s/$1 $2//")\033[00m" #Sucess Dialog
	[[ $1 = '-a' || $1 = '-qi' ]] &&  t['-a']="\033[01;33m >> /$2/: $([[ ! -z $3 ]] && $prt "$*" | sed "s/$1 $2//") <<\033[00m" #Alert Dialog

	if [[ "$1" != "-qi" ]]
	then
		$prt "${t[$1]}"
	else
		$prt "${!t[@]}"
	fi
}
bmr(){
	bmr_a=($@)
	bmr_db='/etc/bmn/.globaldb'
	[[ ! -f $bmr_db ]] && touch $bmr_db #return when the db file doesn't exists

	## Data
	log_hist=($(cat $bmr_db))
	line=($(grep -- "${bmr_a[1]} ${bmr_a[2]}" $bmr_db))
	output_index="$(output -qi)"
	blog_date_str="${date_f[0]}$(date +${date_f[1]})"

	## Switches the bmr verbosity for untrusted executions.
	blog_verbose=1

	## change database file
	[[ ${bmr_a[1]} = 'db='* ]] && declare ${bmr_a[1]} && bmr_db=$db && unset bmr_a[1] db

	## Helper
	[[ $1 = "-h" ]] && $prt "$(output -T "$name_upper Register")

	$(output -t "Commands")
	-rg : Register a line. Use “-rgt” instead to instert a timestamp.
	-srg : Register a single line that can only be updated. Use “-srgt” instead to instert a timestamp.
	-rm : Remove lines by @key.
	-gl : Get lines by @key. Use “-glf” instead to format the line for visibility.
	-gd : Get the line data by @key. Works fine only with single data lines.
	-ed : Substitutes a the data line and keep the @key.
	-sub : Substitutes one line to another.
	-ail : Insert items in a line.
	-ril : Remove items in a line.
	-o : Format the line using the output function. Works fine only with single data lines.

	$(output -t "Data Types")
	-d : Data.
	-a : Alert.
	-s : Sucess.
	-e : Error.

	$(output -t "Using other database")
	You can thange the database declaring the “db=yourdbfile” variable in the first argument."

	## Handy shortcuts
	case $1 in
		-rg|-rgt|-srg|-srgt|-gl|-glf|-gd|-rm|-o) #automatically adds a “-d” data type to a line in some insertions for convenience.
			if [[  $output_index != *"$2"* ]]
			then
				bmr_a=($1 '-d' ${bmr_a[@]:1})
				line=($(grep -- "${bmr_a[1]} ${bmr_a[2]}" $bmr_db))
			fi
		;;
		@*) #adds a alert data type when the arguments are no insertion instructions and a @key are passed, useful for generate bundles alerts quickly.
			bmr_a=('-a' ${bmr_a[@]:0})
			line=($(grep -- "${bmr_a[1]} ${bmr_a[2]}" $bmr_db))
		;;
		-rg*|-srg*|-rm) #check root in inserctions that write in bmn database
			btest -root || return 1
		;;
	esac

	## Insertion Instructions
	case ${bmr_a[0]} in
	"-a"|"-e"|"-d") #quick alert and error register for bundles
	if [[ $output_index != *"${bmr_a[0]}"* || ${bmr_a[1]} != "${bkc}"* || ${bmr_a[@]:2} = *"${bkc}"* ]]
	then
		output -a syntax "bmr ${bmr_a[0]} “${bkc}key” “text arguments (cannot contain ${bkc})”"
		output -d dataTypes ${output_index[@]}
	else
		line=($(grep -- "${bmr_a[0]} ${bmr_a[1]}" $bmr_db))
		if [[ ! -z $line && ${bmr_a[0]} != "-d" && $line != "-e" ]]
		then
			sed -i "/${bmr_a[0]} ${bmr_a[1]}/d" $bmr_db
		fi
		if [[ $line != *"-e"* || ${bmr_a[0]} != "-a" ]]
		then
			echo "${bmr_a[*]}" >> $bmr_db
		fi
		if [[ $blog_verbose = 1 ]]
		then
			output $(echo "${bmr_a[*]}" | sed "s/${bkc}//g")
		fi
	fi
	;;
	'-o') #redirects the line output to the “output()” function.
		if [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* || ${bmr_a[@]:3} = *"${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			output $(echo "${line[*]}" | sed "s/${bkc}//g")
		fi
	;;
	"-rg"|"-rgt") #register a custom value
		if [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* || ${bmr_a[@]:3} = *"${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			if [ ${bmr_a[0]} = '-rgt' ]
			then
				bmr_a[2]="${bmr_a[2]}$blog_date_str"
			fi
			echo "${bmr_a[*]:1}" | sed "s/\n//g" >> $bmr_db
			[[ $blog_verbose = 1 ]] && output -s "bmr" "Line “$(echo "${bmr_a[*]:1}")” registered"
		fi
	;;
	"-srg"|"-srgt") # safe register, if the line exists, replace it with the newest one.
		if [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* || ${bmr_a[@]:3} = *"${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			old_key=${bmr_a[2]}
			if [ ${bmr_a[0]} = '-srgt' ]
			then
				bmr_a[2]="${bmr_a[2]}$blog_date_str"
			fi
			if [ -z "$(bmr -gl ${bmr_a[1]} ${bmr_a[2]})" ]
			then
				echo "${bmr_a[*]:1}" | sed "s/\n//g" >> $bmr_db
			else
				sed -i "/${bmr_a[1]} $old_key/d" $bmr_db
				echo "${bmr_a[*]:1}" | sed "s/\n//g" >> $bmr_db
				unset old_key
			fi
			[[ $blog_verbose = 1 ]] && output -s "bmr" "Safe line “$(echo "${bmr_a[*]:1}")” registered"
		fi
	;;
	"-ail"|"-ril") #add and remove items in a line
		if [[ $output_index != *"${bmr_a[1]}"* || $3 != *"@"* || ${bmr_a[@]:3} = *"${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}keyQwerry” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			if [[ ! -z $line ]]
			then
				if [ ${bmr_a[0]} = "-ail" ]
				then
					sed -i "/${bmr_a[1]} ${bmr_a[2]}/d" $bmr_db
					echo "${line[*]} ${bmr_a[*]:3}" | sed "s/\n//g" >> $bmr_db
					[[ $blog_verbose = 1 ]] && output -s "bmr" "Added “${bmr_a[*]:3}” in line “${line[*]}”"
				else
					bmr_last_bv=$blog_verbose
					bmr_last_line="${line[*]}"
					bmr_irm="${bmr_a[*]:3}"
					blog_verbose=0
					for item in ${bmr_a[@]:3}
					do
						[[ -z $sbl ]] && sbl="${line[*]:2}"
						sbl="$(echo "$sbl" | sed "s/$item//")"
					done
					bmr -sub ${bmr_a[1]} ${bmr_a[2]} ${bmr_a[1]} ${bmr_a[2]} $sbl
					[[ $bmr_last_bv = 1 ]] && output -s "bmr" "Removed “$bmr_irm” in line “$bmr_last_line”"
				fi
			fi
		fi
	;;
	"-ed") #edit a line, keeps the previous key
		if [[ $output_index != *"${bmr_a[1]}"* || $3 != *"${bkc}"* || ${bmr_a[@]:3} = *"${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}keyQwerry” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			if [[ ! -z $line ]]
			then
				sed -i "/${bmr_a[1]} ${bmr_a[2]}/d" $bmr_db
				echo "${bmr_a[1]} ${bmr_a[2]} ${bmr_a[*]:3}" | sed "s/\n//g" >> $bmr_db
				[[ $blog_verbose = 1 ]] && output -s "bmr" "Line “${line[1]}” edited : [${line[@]:2}] >> [${bmr_a[*]:3}]"
			fi
		fi
	;;
	"-sub") #substitute the line
		if [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* ]] ||  [[ $output_index != *"$4"* || $5 != "${bkc}"* || ${bmr_a[@]:5} = *"${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}keyQwerry” “-d” “${bkc}key” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			if [[ ! -z $line ]]
			then
				sed -i "/${bmr_a[1]} ${bmr_a[2]}/d" $bmr_db
				echo "${bmr_a[*]:3}" | sed "s/\n//g" >> $bmr_db
				[[ $blog_verbose = 1 ]] && output -s "bmr" "Line “${line[@]}” substituted to “$(echo "${bmr_a[*]:3}")”"
			fi
		fi
	;;
	"-rm") #remove a type and key line
		if  [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key”"
			output -d dataTypes ${output_index[@]}
		else
			sed -i "/${bmr_a[1]} ${bmr_a[2]}/d" $bmr_db
			[[ $blog_verbose = 1 ]] && output -a "bmr" "Line “${line[@]}” removed"
		fi
	;;
	"-rma") #delete all key lines
		if  [[ "${bmr_a[1]}" != "${bkc}"* ]]
		then
			output -a syntax 'bmr -del “${bkc}key”'
		else
			sed -i "/${bmr_a[1]}/d" $bmr_db
			[[ $blog_verbose = 1 ]] && output -a "bmr" "All lines with the key “${bmr_a[1]}” removed"
		fi
	;;
	"-gl"|"-glf") #returns the line with the found value, -glf for remove @.
		if  [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key”"
			output -d dataTypes ${output_index[@]}
		else
			if [[ ${bmr_a[0]} = "-gl" ]]
			then
				[ ! -z $line ] && grep -- "${bmr_a[1]} ${bmr_a[2]}" $bmr_db
			else
				[ ! -z $line ] && grep -- "${bmr_a[1]} ${bmr_a[2]}" $bmr_db | sed "s/${bkc}//" | sed "s/${date_f[0]}/ /" | sed "s/${bmr_a[1]}//"
			fi
		fi
	;;
	"-gal") #returns all the key lines
		if  [[ "${bmr_a[1]}" != "${bkc}"* ]]
		then
			output -d "syntax" "bmr ${bmr_a[0]} “${bkc}key”"
		else
			grep -- "${bmr_a[1]}" $bmr_db
		fi
	;;
	"-gd") #returns only the data without type or key
		if  [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key”"
			output -d dataTypes ${output_index[@]}
		else
			[ ! -z $line ] && echo "${line[*]:2}"
		fi
	;;
	esac
}
bmr $@
