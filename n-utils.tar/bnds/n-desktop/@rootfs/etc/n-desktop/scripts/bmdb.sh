#!/usr/bin/env bash
prt="echo -e"
bkc=@
output(){
out_a=($*)
	declare -A t
	[[ $1 = '-d' ]] &&  t['-d']="\033[01m [$2]: $([[ ! -z $3 ]] && $prt "$*" | sed "s/$1 $2//")\033[00m" #Dialog, bmr Data
	[[ $1 = '-a' ]] &&  t['-a']="\033[01;33m >> /$2/: $([[ ! -z $3 ]] && $prt "$*" | sed "s/$1 $2//") <<\033[00m" #Alert Dialog

	$prt "${!t[@]}"
}
bmr(){
	bmr_a=($@)
	bmr_db='/etc/n-desktop/configs/database'
	[[ ${bmr_a[1]} = 'db='* ]] && declare ${bmr_a[1]} && bmr_db=$db && unset bmr_a[1] db
	[[ ! -f $bmr_db ]] && output -a "NDE" "Database file “$bmr_db” not found" #return when the db file doesn't exists

	## Data
	log_hist=($(cat $bmr_db))
	line=($(grep -- "${bmr_a[1]} ${bmr_a[2]}" $bmr_db))
	output_index="-d"

	## Switches the bmr verbosity for untrusted executions.
	blog_verbose=1

	## Handy shortcuts
	case $1 in
		-rg|-rgt|-srg|-srgt|-gl|-glf|-gd|-rm|-o) #automatically adds a “-d” data type to a line in some insertions for convenience.
			if [[  $output_index != *"$2"* ]]
			then
				bmr_a=($1 '-d' ${bmr_a[@]:1})
				line=($(grep -- "${bmr_a[1]} ${bmr_a[2]}" $bmr_db))
			fi
		;;
		@*) #adds a alert data type when the arguments are no insertion instructions and a @key are passed, useful for generate bundles alerts quickly.
			bmr_a=('-a' ${bmr_a[@]:0})
			line=($(grep -- "${bmr_a[1]} ${bmr_a[2]}" $bmr_db))
		;;
		-rg*|-srg*|-rm) #check root in inserctions that write in bmn database
			btest -root || return 1
		;;
	esac

	## Insertion Instructions
	case ${bmr_a[0]} in
	"-rg") #register a custom value
		if [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"*  ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			echo "${bmr_a[*]:1}" | sed "s/\n//g" >> $bmr_db
			[[ $blog_verbose = 1 ]] && output -s "bmr" "Line “$(echo "${bmr_a[*]:1}")” registered"
		fi
	;;
	"-srg") # safe register, if the line exists, replace it with the newest one.
		if [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"*  ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			old_key=${bmr_a[2]}
			if [ -z "$(bmr -gl ${bmr_a[1]} ${bmr_a[2]})" ]
			then
				echo "${bmr_a[*]:1}" | sed "s/\n//g" >> $bmr_db
			else
				sed -i "/${bmr_a[1]} $old_key/d" $bmr_db
				echo "${bmr_a[*]:1}" | sed "s/\n//g" >> $bmr_db
				unset old_key
			fi
			[[ $blog_verbose = 1 ]] && output -s "bmr" "Safe line “$(echo "${bmr_a[*]:1}")” registered"
		fi
	;;
	"-ail"|"-ril") #add and remove items in a line
		if [[ $output_index != *"${bmr_a[1]}"* || $3 != *"@"*  ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}keyQwerry” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			if [[ ! -z $line ]]
			then
				if [ ${bmr_a[0]} = "-ail" ]
				then
					sed -i "/${bmr_a[1]} ${bmr_a[2]}/d" $bmr_db
					echo "${line[*]} ${bmr_a[*]:3}" | sed "s/\n//g" >> $bmr_db
					[[ $blog_verbose = 1 ]] && output -s "bmr" "Added “${bmr_a[*]:3}” in line “${line[*]}”"
				else
					bmr_last_bv=$blog_verbose
					bmr_last_line="${line[*]}"
					bmr_irm="${bmr_a[*]:3}"
					blog_verbose=0
					for item in ${bmr_a[@]:3}
					do
						[[ -z $sbl ]] && sbl="${line[*]:2}"
						sbl="$(echo "$sbl" | sed "s/$item//")"
					done
					bmr -sub ${bmr_a[1]} ${bmr_a[2]} ${bmr_a[1]} ${bmr_a[2]} $sbl
					[[ $bmr_last_bv = 1 ]] && output -s "bmr" "Removed “$bmr_irm” in line “$bmr_last_line”"
				fi
			fi
		fi
	;;
	"-ed") #edit a line, keeps the previous key
		if [[ $output_index != *"${bmr_a[1]}"* || $3 != *"${bkc}"*  ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}keyQwerry” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			if [[ ! -z $line ]]
			then
				sed -i "/${bmr_a[1]} ${bmr_a[2]}/d" $bmr_db
				echo "${bmr_a[1]} ${bmr_a[2]} ${bmr_a[*]:3}" | sed "s/\n//g" >> $bmr_db
				[[ $blog_verbose = 1 ]] && output -s "bmr" "Line “${line[1]}” edited : [${line[@]:2}] >> [${bmr_a[*]:3}]"
			fi
		fi
	;;
	"-sub") #substitute the line
		if [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* ]] ||  [[ $output_index != *"$4"* || $5 != "${bkc}"* || ${bmr_a[@]:5} = *"${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}keyQwerry” “-d” “${bkc}key” “text arguments (cannot contain ${bkc})”"
			output -d dataTypes ${output_index[@]}
		else
			if [[ ! -z $line ]]
			then
				sed -i "/${bmr_a[1]} ${bmr_a[2]}/d" $bmr_db
				echo "${bmr_a[*]:3}" | sed "s/\n//g" >> $bmr_db
				[[ $blog_verbose = 1 ]] && output -s "bmr" "Line “${line[@]}” substituted to “$(echo "${bmr_a[*]:3}")”"
			fi
		fi
	;;
	"-rm") #remove a type and key line
		if  [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key”"
			output -d dataTypes ${output_index[@]}
		else
			sed -i "/${bmr_a[1]} ${bmr_a[2]}/d" $bmr_db
			[[ $blog_verbose = 1 ]] && output -a "bmr" "Line “${line[@]}” removed"
		fi
	;;
	"-rma") #delete all key lines
		if  [[ "${bmr_a[1]}" != "${bkc}"* ]]
		then
			output -a syntax 'bmr -del “${bkc}key”'
		else
			sed -i "/${bmr_a[1]}/d" $bmr_db
			[[ $blog_verbose = 1 ]] && output -a "bmr" "All lines with the key “${bmr_a[1]}” removed"
		fi
	;;
	"-gl"|"-glf") #returns the line with the found value, -glf for remove @.
		if  [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key”"
			output -d dataTypes ${output_index[@]}
		else
			if [[ ${bmr_a[0]} = "-gl" ]]
			then
				[ ! -z $line ] && grep -- "${bmr_a[1]} ${bmr_a[2]}" $bmr_db
			elif [[ ${bmr_a[0]} = "-glf" ]]
			then
				[ ! -z $line ] && grep -- "${bmr_a[1]} ${bmr_a[2]}" $bmr_db | sed "s/${bkc}//" | sed "s/${bmr_a[1]}//"
			fi
		fi
	;;
	"-gappl")
		bmr -gl @nde_appl | cut -d" "  -f4-
	;;
	"-gal") #returns all the key lines
		if  [[ "${bmr_a[1]}" != "${bkc}"* ]]
		then
			output -d "syntax" "bmr ${bmr_a[0]} “${bkc}key”"
		else
			grep -- "${bmr_a[1]}" $bmr_db
		fi
	;;
	"-gd") #returns only the data without type or key
		if  [[ $output_index != *"${bmr_a[1]}"* || ${bmr_a[2]}  != "${bkc}"* ]]
		then
			output -a syntax "bmr ${bmr_a[0]} “-d” “${bkc}key”"
			output -d dataTypes ${output_index[@]}
		else
			[ ! -z $line ] && echo "${line[*]:2}"
		fi
	;;
	esac
}
bmr $*
