#!/bin/bash
source /etc/n-desktop/configs/sh
dmenu_run -i -p "exec:" -nf $txt_inactive -nb $color_background -sb $color_main -sf $txt_main $*
