#!/bib/bash
source /etc/n-desktop/configs/sh
for i in $(ndb -gl @nde_appl)
do
    if [[ $i = "@"* ]]
    then
        applet=($(ndb -gd $i))
        pkill ${applet}
        [[ $applet != "null" ]] && notify-send -h string:x-dunst-stack-tag:test "NDE / Exiting session" "Resolving “${applet}”"
    fi
done
i3-msg exit
