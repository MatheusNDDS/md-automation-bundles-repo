#!/bib/bash
pkill -f "sh -c while true"
swaymsg exit
