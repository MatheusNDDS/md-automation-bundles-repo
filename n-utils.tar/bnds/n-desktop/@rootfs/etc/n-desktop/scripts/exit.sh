#1/bib/bash
ndb='bmn -api bmr'
notify-send "N OS Desktop" "Exiting session"
for i in $($ndb -gl @nde_appl)
do
    if [[ $i = "@"* ]]
    then
        applet=($($ndb -gd $i))
        nohup pkill ${applet} &
    fi
done
i3-msg exit
