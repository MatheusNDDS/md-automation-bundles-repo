#!/bin/bash
source /etc/n-desktop/configs/sh
dmenu -i -nf $txt_inactive -nb $color_background -sb $color_main -sf $txt_main $*
