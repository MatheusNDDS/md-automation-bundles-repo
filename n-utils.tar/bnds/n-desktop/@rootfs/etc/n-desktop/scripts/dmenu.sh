#!/bin/bash
source /etc/n-desktop/configs/sh
menu_file=/tmp/n.menu
args=($*)
prompt="@:"
[[ $2 = "p="* ]] && prompt=${args[1]:2} && unset args[1]

echo ${args[@]:1} | tr " " "\n" > $menu_file
case $1 in
    --menu)
        cat $menu_file | dmenu -p $prompt -nf $color_txt_inactive -nb $color_background -sb $color_main -sf $color_txt_main
    ;;
    --run)
        dmenu_run -p $prompt -nf $color_txt_inactive -nb $color_background -sb $color_main -sf $color_txt_main
    ;;
    --input)
        dmenu -p $prompt -nf $color_txt_inactive -nb $color_background -sb $color_main -sf $color_txt_main
    ;;
    *)
        dmenu -nf $color_txt_inactive -nb $color_background -sb $color_main -sf $color_txt_main ${args[@]:1}
    ;;
esac
