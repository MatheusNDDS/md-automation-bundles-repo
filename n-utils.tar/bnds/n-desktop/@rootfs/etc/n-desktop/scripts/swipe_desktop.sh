#!/usr/bin/env bash

DIRECTION=$1
CURRENT=$(swaymsg -t get_workspaces | jq '.[] | select(.focused==true).name' | cut -d"\"" -f2)

MIN=$(swaymsg -t get_workspaces | jq '.[0].num')
if [ $CURRENT -eq $MIN ] && [ $DIRECTION = "next" ]; then
	exit 0
fi

MAX=$(swaymsg -t get_workspaces | jq '.[-1].num')
if [ $CURRENT -eq $MAX ] && [ $DIRECTION = "prev" ]; then
	exit 0
fi

swaymsg workspace $DIRECTION
