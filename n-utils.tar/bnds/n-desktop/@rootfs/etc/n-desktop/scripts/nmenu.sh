#!/bin/bash

source ~/n-desktop/configs/sh
menu_file=/tmp/n.menu
args=($*)
prompt="@:"


#rofi -show combi -config $nconfigs/rofi/config.rasi -plugin-path $nconfigs/rofi/plugins

[[ $2 = "p="* ]] && prompt=${args[1]:2} && unset args[1]

echo ${args[@]:1} | tr " " "\n" > $menu_file
case $1 in
    --menu)
        cat $menu_file | rofi -dmenu -p $prompt -config $nconfigs/rofi/modes/runner.rasi -plugin-path $nconfigs/rofi/plugins
    ;;
    --run)
        PATH=$PATH:$nconfigs/rofi/runnits/ && rofi -matching-negate-char '\x0' -show combi -p $prompt -config $nconfigs/rofi/modes/runner.rasi -plugin-path $nconfigs/rofi/plugins
    ;;
    --input)
        rofi -dmenu  -l 0 -p $prompt -run-command "printf {cmd}" -config $nconfigs/rofi/modes/runner.rasi
    ;;
    --files)
        context=$(cat ~/dirs | rofi -dmenu -p $prompt -config $nconfigs/rofi/modes/runner.rasi)
	xdg-open $context
    ;;
    *)
        rofi -config $nconfigs/rofi/config.rasi -plugin-path $nconfigs/rofi/plugins ${args[@]:1}
    ;;
esac
