#!/bin/bash
wp=$(swaymsg -t get_workspaces | jq -r 'map(select(.focused))[0].num')
wp_len=( 1 9 )

case $1 in
    --next)
        wp=$((wp + 1))
        [[ $wp > 1 ]] && swaymsg workspace $wp
    ;;
    --prev)
        wp=$((wp - 1))
        [[ $wp != 0 ]] && swaymsg workspace $wp
    ;;
    --get)
    	printf $wp
    ;;
esac

