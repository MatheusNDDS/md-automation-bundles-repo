#!/bin/bash
wp=$(i3-msg -t get_workspaces | jq -r 'map(select(.focused))[0].num')
wp_len=( 1 9 )

case $1 in
    --next)
        wp=$((wp + 1))
        [[ $wp > 1 ]] && i3-msg workspace $wp
    ;;
    --prev)
        wp=$((wp - 1))
        [[ $wp != 0 ]] && i3-msg workspace $wp
    ;;
    --get)
    	printf $wp
    ;;
esac

