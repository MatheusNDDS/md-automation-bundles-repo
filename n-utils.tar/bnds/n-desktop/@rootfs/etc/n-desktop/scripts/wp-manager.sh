#!/bin/bash
wp=$(i3-msg -t get_workspaces | jq '.[] | select(.focused==true).name' | cut -d"\"" -f2)
wp_len=( 1 9 )

case $1 in
    --next)
        wp=$((wp + 1))
        [[ $wp > 1 ]] && i3-msg workspace $wp
    ;;
    --prev)
        wp=$((wp - 1))
        [[ $wp != 0 ]] && i3-msg workspace $wp
    ;;
esac

