#!/bin/bash
source /etc/n-desktop/configs/sh
modes="$(powerprofilesctl list | grep -v '   ' | tr -d '\n' | tr -d '* ' | tr ':' ' ')"
powerprofilesctl set $(n-desktop --menu "p=Power_Profile: $modes")
