#!/bin/bash
source /etc/n-desktop/configs/sh
[[ ! -f  ~/.modes ]] && powerprofilesctl list | grep -v '   ' | tr -d '\n' | tr -d '* ' | tr ':' '\n' > ~/.modes
powerprofilesctl set $(cat ~/.modes | ndmenu -p "power_profile:")
