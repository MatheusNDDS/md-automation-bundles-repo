#!/bin/bash
modes="$(powerprofilesctl list | grep -v '   ' | tr -d '\n' | tr -d '* ' | tr ':' ' ')"
powerprofilesctl set $(n-desktop --menu "p=Power_Mode: $modes")
