run(){
      dunst -config /etc/n-desktop/configs/dunstrc
      [ $? != 0 ] && run
}
run
