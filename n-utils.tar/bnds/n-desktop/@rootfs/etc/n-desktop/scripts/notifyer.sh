run(){
      dunst -config ~/.n-desktop/configs/dunstrc
      [ $? != 0 ] && run
}
run
