export PATH=$PATH:/usr/local/go/bin
name="n-desktop"
# rm -rf go.*
# go mod init main && go mod tidy
go build main.go
[[ $? = 0 ]] && rm -rf ../@rootfs/usr/bin/$name && mv main ../@rootfs/usr/bin/$name || exit 1
[[ $1 = 'i' ]] && sudo bmn -di ../../$name
[[ $1 = 'b' ]] && sudo cp -r ../@rootfs/usr/bin/$name /bin/$name
