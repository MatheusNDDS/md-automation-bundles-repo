package main

import (
	"fmt"
	"os"
	"os/exec"
	"os/user"
	"strconv"
	"strings"
)
var userData , _ = user.Current()
var userHome = "/home/"+userData.Username

var mainArgs = os.Args[1:]
var mainPath = userHome+"/n-desktop"
var configs = mainPath+"/configs"
var bindsPath = mainPath+"/system/binds/"
var mainConfig = mainPath+"/main"
var scripts = mainPath+"/scripts/"
var templates = mainPath+"/system/templates"
var nShFile = configs+"/sh"
var dunstRcFile = configs+"/dunstrc"
var rofiColorsFile = configs+"/rofi/style.rasi"
var waybarStyleFile = configs+"/waybar/wb_style.css"

var nSh = `
#N Desktop
npath=/etc/n-desktop
nconfigs=$npath/configs
nscripts=$npath/scripts

#Themes:
color_main="<COLOR_MAIN>"
color_border="<COLOR_BORDER>"
color_inactive="<COLOR_INACTIVE>"
color_background="<COLOR_BACKGROUND>"
color_tab_background="<COLOR_TAB_BACKGROUND>"
color_tab_txt_inactive="<COLOR_TAB_TXT_INACTIVE>"
color_txt_main="<COLOR_TXT_MAIN>"
color_txt_inactive="<COLOR_TXT_INACTIVE>"

#Utilities:
termx="<TERMX>"
terminal="<TERMINAL>"
notifyer="<NOTIFYER>"
file_manager="<FILE_MANAGER>"
browser="<BROWSER>"
hidden_screenprt="<HIDDEN_SCREENPRT>"
task_manager="<TASK_MANAGER>"
screenprt="<SCREENPRT>"
dropterminal="<DROPTERMINAL>"
polkit="<POLKIT>"
separator_symbol="<SEPARATOR_SYNBOL>"
compositor="<COMPOSITOR>"

#Tools:
alias ndb="$nscripts/bmdb.sh"
shopt -s expand_aliases
`
// Read template files
var swayConfigBuff , _ = os.ReadFile(templates+"/main")
var dunstRcBuff , _ = os.ReadFile(templates+"/dunstrc")
var rofiColorsBuff , _ = os.ReadFile(templates+"/style.rasi")
var waybarStyleBuff , _ = os.ReadFile(templates+"/wb_style.css")

// Converts io buffer into string type
var swayConfig = string(swayConfigBuff)
var dunstRc = string(dunstRcBuff)
var rofiColors = string(rofiColorsBuff)
var waybarStyle = string(waybarStyleBuff)


func sh(doStdout byte,cmd string,args ...string)(output string){
	stdout, err := exec.Command(cmd, args...).Output()
	if doStdout == 1 {
		if err != nil {
			fmt.Println(err)
		}else{
			fmt.Printf(string(stdout))
		}
	}
	output = string(stdout[:])
return
}

func dbSh(doStdout byte,args ...string)(output string){
	stdout, err := exec.Command(scripts+"/bmdb.sh", args...).Output()
	if doStdout == 1 {
		if err != nil {
			fmt.Println(err)
		}else{
			fmt.Printf(string(stdout))
		}
	}
	output = string(stdout)
return
}

func config(opt string, req string)(dataOut string){
	switch opt {
		case "-set":
			props := strings.Split(req, "=")
			if ( props[1] != "" ) {
				dbSh(0,"-srg","@config_"+props[0],props[1])
				dataOut = props[0]+"="+props[1]
			}else{
				dbSh(0,"-rm","@config_"+props[0])
			}
		case "-list":
			keys := dbSh(0, "-gal", "@config_")
			keys = strings.ReplaceAll(keys, "-d @config_", "\n",)
			fmt.Println(keys)
		case "-get":
			ref := dbSh(0, "-gd", "@config_"+req)
			if ( ref != "" && ref[0:2] == "--" ) {
				dataOut = config("-get",string(ref[2:]))
			}else{
				dataOut = ref
			}
			dataOut = strings.ReplaceAll(dataOut,"\n", "")
	}
	return
}

func appletMn(opt string, applName string, mainCommand string){
	commandStr := "exec --no-startup-id "+mainCommand
	switch opt {
		case "-add":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			dbSh(0,"-srg","@applet_"+applName, commandStr)
			sh(0,"swaymsg", commandStr)
			desktopUpdate(false)
			fmt.Println("applet “"+applName+"” added \n"+"Main Command : "+commandStr)
		case "-del":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			applData := strings.Split(dbSh(0,"-gl", "@applet_"+applName), " ")
			dbSh(0,"-rm",applData[1])
			sh(0,"pkill",applData[2])
			desktopUpdate(false)
			fmt.Println("applet “"+applName+"” deleted")
		case "-list":
			keys := dbSh(0, "-gal", "@applet_")
			keys = strings.ReplaceAll(keys, "-d @applet_", "> ",)
			fmt.Println(keys)
	}
}

func keyBindMn(opt string, bindScope string, bind string, commandLine []string){
	commandStr := strings.Join(commandLine," ")
	switch opt {
		case "-add":
			os.WriteFile(bindsPath+"/"+bindScope+"/"+bind,[]byte("bindsym "+bind+" "+commandStr),0777)
			desktopUpdate(false)
		case "-del":
			os.Remove(bindsPath+"/"+bindScope+"/"+bind)
			desktopUpdate(false)
		case "-list":
			//
	}

}

func themeMn(opt string, req string){
	// GTK Theme 
	gtkLightTheme := config("-get","gtk_light_theme")
	gtkDarkTheme := config("-get","gtk_dark_theme")
	gtkLightIconTheme := config("-get","gtk_light_icon_theme")
	gtkDarkIconTheme := config("-get","gtk_dark_icon_theme")
	// Wallpaper
	lightWallpaper := config("-get","light_wallpaper")
	darkWallpaper := config("-get","dark_wallpaper")
	// wallpaperCmd := config("-get","wallpaper_cmd")
	// Desktop
	themeState := config("-get","theme_state")
	if (themeState == ""){ themeState = "light"; config("-set","theme_state="+themeState)}

	switch opt {
		case "-switch-dark":
			sh(0,"swaymsg","exec "+"gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark'")
			sh(0,"swaymsg","exec "+"gsettings set org.gnome.desktop.interface gtk-theme "+gtkDarkTheme)
			sh(0,"swaymsg","exec "+"gsettings set org.gnome.desktop.interface icon-theme "+gtkDarkIconTheme)
			sh(0,"swaymsg", "output * bg "+darkWallpaper+" fill")
			config("-set","theme_state=dark")
		
		case "-switch-light":
			sh(0,"swaymsg","exec "+"gsettings set org.gnome.desktop.interface color-scheme 'prefer-light'")
			sh(0,"swaymsg","exec "+"gsettings set org.gnome.desktop.interface gtk-theme "+gtkLightTheme)
			sh(0,"swaymsg","exec "+"gsettings set org.gnome.desktop.interface icon-theme "+gtkLightIconTheme)
			sh(0,"swaymsg", "output * bg "+lightWallpaper+" fill")
			config("-set","theme_state=light")
		
		case "--set-gtk-dark-theme", "-gtkdth":
			config("-set","gtk_dark_theme="+req)
 			themeMn("-switch-dark","")
			fmt.Println("Theme updated\n		-- light --\n			GTK: "+gtkLightTheme+" \n			Icons: "+gtkLightIconTheme+" \n			Wallpaper: "+lightWallpaper+" \n\n		-- Dark --\n			GTK: "+gtkDarkTheme+" \n			Icons: "+gtkDarkIconTheme+" \n			Wallpaper: "+darkWallpaper)
 		
 		case "--set-gtk-light-theme", "-gtklth":
			config("-set","gtk_light_theme="+req)
 			themeMn("-switch-dark","")
			fmt.Println("Theme updated\n		-- light --\n			GTK: "+gtkLightTheme+" \n			Icons: "+gtkLightIconTheme+" \n			Wallpaper: "+lightWallpaper+" \n\n		-- Dark --\n			GTK: "+gtkDarkTheme+" \n			Icons: "+gtkDarkIconTheme+" \n			Wallpaper: "+darkWallpaper)

		case "--set-light-icons", "-sli":
			config("-set","gtk_light_icon_theme="+req)
			themeMn("-switch-light","")
			fmt.Println("Theme updated\n		-- light --\n			GTK: "+gtkLightTheme+" \n			Icons: "+gtkLightIconTheme+" \n			Wallpaper: "+lightWallpaper+" \n\n		-- Dark --\n			GTK: "+gtkDarkTheme+" \n			Icons: "+gtkDarkIconTheme+" \n			Wallpaper: "+darkWallpaper)		
		case "--set-dark-icons", "-sdi":
			config("-set","gtk_dark_icon_theme="+req)
			themeMn("-switch-dark","")
			fmt.Println("Theme updated\n		-- light --\n			GTK: "+gtkLightTheme+" \n			Icons: "+gtkLightIconTheme+" \n			Wallpaper: "+lightWallpaper+" \n\n		-- Dark --\n			GTK: "+gtkDarkTheme+" \n			Icons: "+gtkDarkIconTheme+" \n			Wallpaper: "+darkWallpaper)		

		case "--set-light-wallpaper", "-slwpp":
			config("-set","light_wallpaper="+req)
			themeMn("-switch-light","")
			fmt.Println("Theme updated\n		-- light --\n			GTK: "+gtkLightTheme+" \n			Icons: "+gtkLightIconTheme+" \n			Wallpaper: "+lightWallpaper+" \n\n		-- Dark --\n			GTK: "+gtkDarkTheme+" \n			Icons: "+gtkDarkIconTheme+" \n			Wallpaper: "+darkWallpaper)
		
		case "--set-dark-wallpaper", "-sdwpp":
			config("-set","dark_wallpaper="+req)
			themeMn("-switch-dark","")
			fmt.Println("Theme updated\n		-- light --\n			GTK: "+gtkLightTheme+" \n			Icons: "+gtkLightIconTheme+" \n			Wallpaper: "+lightWallpaper+" \n\n		-- Dark --\n			GTK: "+gtkDarkTheme+" \n			Icons: "+gtkDarkIconTheme+" \n			Wallpaper: "+darkWallpaper)
		
		case "--set-wallpaper-cmd", "-swppc":
			config("-set","wallpaper_cmd="+req)
		
		case "--restore-theme":
			switch themeState {
				case "light":
					themeMn("-switch-light","")
				
				case "dark":
					themeMn("-switch-dark","")
			}
	}
}

func extensionMn(opt string, file string){
	switch opt {
		case "--add-extension", "+e":
			//
		case "--del-extension", "-e":
			//
		case "--list-extension", "-lE":
			//
	}
}

func desktopUpdate(restart bool){
	fmt.Println(" Wait, Updating the desktop ...")

	applets := dbSh(0,"-gappl")

	//Tools
	terminal := config("-get","terminal")
	notifyer := config("-get","nofifyer")
	fileManager := config("-get","file_manager")
	browser := config("-get","browser")
	screenprt := config("-get","screenprt")
	hiddenScreenprt := config("-get","hidden_screenprt")
	taskManager := config("-get","task_manager")
	dropTerminal := config("-get","dropterminal")
	runner := config("-get","runner")
	//Settings
	termx := config("-get","termx")
	compositor := config("-get","compositor")
	barMode := config("-get","bar_mode")
	workspaceLayout := config("-get","workspace_layout")
	lockScreen := config("-get","lock_screen")
	focusFollowMouse := config("-get", "focus_follows_mouse")
	polkit := config("-get", "polkit")
	//font
	font := config("-get","font")
	fontName := config("-get","font_name")
	fontSize := config("-get","font_size")
	fontStyles := config("-get","font_styles")
	//theme
	dunstFont := strings.ReplaceAll(font,"pango:","")
	barSeparatorSynbol := config("-get","bar_separator_symbol")
	colorMain := config("-get","color_main")
	colorBorder := config("-get","color_border")
	colorInactive := config("-get","color_inactive")
	colorBackground := config("-get","color_background")
	colorTabBackground := config("-get","color_tab_background")
	colorTxtMain := config("-get","color_txt_main")
	colorTabTxtInactive := config("-get","color_tab_txt_inactive")
	colorTxtInactive := config("-get","color_txt_inactive")
	wallpaper := config("-get","light_wallpaper")
	//Tools
	//strTest = strings.Contain("terminal") ; if( strTest == false ){terminal = "stterm" ; config("-set", "terminal="+terminal)}
	if( terminal == "" ){terminal= "stterm" ; config("-set", "terminal="+terminal)}
	if( notifyer == "" ){notifyer= "/etc/n-desktop/scripts/notifyer.sh" ; config("-set", "notifyer="+notifyer)}
	if( fileManager == "" ){fileManager = "stterm mc" ; config("-set", "file_manager="+fileManager)}
	if( browser == "" ){browser = "stterm lynx www.google.com" ; config("-set", "browser="+browser)}
	if( taskManager == "" ){taskManager = "stterm htop" ; config("-set", "task_manager="+taskManager)}
	if( dropTerminal == "" ){dropTerminal = "null" ; config("-set", "dropterminal="+dropTerminal)}
	if( runner == "" ){runner = `n-desktop --menu-run "N" ` ; config("-set", "runner="+runner)}
	// Settings
	if( termx == "" ){termx = "stterm" ; config("-set", "termx="+termx)}
	if( compositor == "" ){compositor = "picom --no-ewmh-fullscreen -b --config /etc/n-desktop/configs/picom" ; config("-set", "compositor="+compositor)}
	if( barMode == "" ){barMode = "dock" ; config("-set", "bar_mode="+barMode)}
	if( barSeparatorSynbol == "" ){barSeparatorSynbol = "," ; config("-set", "bar_separator_symbol="+barSeparatorSynbol)}
	if( workspaceLayout == "" ){workspaceLayout= "tabbed" ; config("-set", "workspace_layout="+workspaceLayout)}
	if( lockScreen == "" ){lockScreen= "swaylock" ; config("-set", "lock_screen="+lockScreen)}
	if( focusFollowMouse == "" ){focusFollowMouse= "yes" ; config("-set", "focus_follows_mouse="+focusFollowMouse)}
	//font
	if( font == "" ){font = "Dejavu Sans Mono 9 " ; config("-set", "font="+font)}
	if( fontName == "" ){fontName = "Dejavu Sans" ; config("-set", "font_name="+fontName)}
	if( fontSize == "" ){fontSize = "9" ; config("-set", "font_size="+fontSize)}
	if( fontStyles == "" ){fontStyles = "" ; config("-set", "font_styles="+fontStyles)}
	//themes
	if( wallpaper == "" ){wallpaper = mainPath+"/assets/default-light.png" ; config("-set", "light_wallpaper="+wallpaper)}
	if( colorMain == "" ){colorMain = "#ffffff" ; config("-set", "color_main="+colorMain)}
	if( colorInactive == "" ){colorInactive = "#4c4c4c" ; config("-set", "color_inactive="+colorInactive)}
	if( colorBackground == "" ){colorBackground = "#000000" ; config("-set", "color_background="+colorBackground)}
	if( colorTabBackground == "" ){colorTabBackground = "#1a1a1a" ; config("-set", "color_tab_background="+colorTabBackground)}
	if( colorBorder == "" ){colorBorder = colorBackground ; config("-set", "color_border="+colorBorder)}
	if( colorTxtMain == "" ){colorTxtMain = "#000000" ; config("-set", "color_txt_main="+colorTxtMain)}
	if( colorTxtInactive == "" ){colorTxtInactive= "#ffffff" ; config("-set", "color_txt_inactive="+colorTxtInactive)}
	if( colorTabTxtInactive == "" ){colorTabTxtInactive = colorTxtInactive ; config("-set", "color_tab_txt_inactive="+colorTabTxtInactive)}

//sway Config builder
	//Tools
	swayConfig = strings.ReplaceAll(swayConfig, "<TERMINAL>", terminal,)
	swayConfig = strings.ReplaceAll(swayConfig, "<NOTIFYER>", notifyer,)
	swayConfig = strings.ReplaceAll(swayConfig, "<FILE_MANAGER>", fileManager,)
	swayConfig = strings.ReplaceAll(swayConfig, "<BROWSER>", browser,)
	swayConfig = strings.ReplaceAll(swayConfig, "<TASK_MANAGER>", taskManager,)
	swayConfig = strings.ReplaceAll(swayConfig, "<SCREENPRT>", screenprt,)
	swayConfig = strings.ReplaceAll(swayConfig, "<HIDDEN_SCREENPRT>", hiddenScreenprt,)
	swayConfig = strings.ReplaceAll(swayConfig, "<DROPTERMINAL>", dropTerminal,)
	swayConfig = strings.ReplaceAll(swayConfig, "<RUNNER>", runner,)
	//Settings
	swayConfig = strings.ReplaceAll(swayConfig, "<TERMX>", termx,)
	swayConfig = strings.ReplaceAll(swayConfig, "<COMPOSITOR>", compositor,)
	swayConfig = strings.ReplaceAll(swayConfig, "<BARMODE>", barMode,)
	swayConfig = strings.ReplaceAll(swayConfig, "<WORKSPACE_LAYOUT>", workspaceLayout,)
	swayConfig = strings.ReplaceAll(swayConfig, "<LOCK_SCREEN>", lockScreen,)
	swayConfig = strings.ReplaceAll(swayConfig, "<POLKIT>", polkit,)
	swayConfig = strings.ReplaceAll(swayConfig, "<FOCUS_FOLLOW_MOUSE>", focusFollowMouse,)
	//Font
	swayConfig = strings.ReplaceAll(swayConfig, "<FONT>", font,)
	swayConfig = strings.ReplaceAll(swayConfig, "<FONT_NAME>", fontName,)
	swayConfig = strings.ReplaceAll(swayConfig, "<FONT_SIZE>", fontSize,)
	swayConfig = strings.ReplaceAll(swayConfig, "<FONT_STYLES>", fontStyles,)
	//Theme
	swayConfig = strings.ReplaceAll(swayConfig, "<FONT>", font,)
	swayConfig = strings.ReplaceAll(swayConfig, "<WALLPAPER>", wallpaper,)
	swayConfig = strings.ReplaceAll(swayConfig, "<SEPARATOR_SYNBOL>", barSeparatorSynbol,)
	swayConfig = strings.ReplaceAll(swayConfig, "<COLOR_MAIN>", colorMain,)
	swayConfig = strings.ReplaceAll(swayConfig, "<COLOR_BORDER>", colorBorder,)
	swayConfig = strings.ReplaceAll(swayConfig, "<COLOR_INACTIVE>", colorInactive,)
	swayConfig = strings.ReplaceAll(swayConfig, "<COLOR_BACKGROUND>", colorBackground,)
	swayConfig = strings.ReplaceAll(swayConfig, "<COLOR_TAB_BACKGROUND>", colorTabBackground,)
	swayConfig = strings.ReplaceAll(swayConfig, "<TXT_MAIN>", colorTxtMain,)
	swayConfig = strings.ReplaceAll(swayConfig, "<TXT_INACTIVE>", colorTxtInactive,)
	swayConfig = strings.ReplaceAll(swayConfig, "<TAB_TXT_INACTIVE>", colorTabTxtInactive,)
	//Applets
	swayConfig = strings.ReplaceAll(swayConfig, "<NDE_APPLETS>", applets,)
	swayConfig = strings.ReplaceAll(swayConfig, "<NDE_CONFIGS>", configs,)
	//Embedded
	swayConfig = strings.ReplaceAll(swayConfig, "<NSCRIPTS>", scripts,)

//Shell Variables
	nSh = strings.ReplaceAll(nSh, "<TERMINAL>", terminal,)
	nSh = strings.ReplaceAll(nSh, "<NOTIFYER>", notifyer,)
	nSh = strings.ReplaceAll(nSh, "<FILE_MANAGER>", fileManager,)
	nSh = strings.ReplaceAll(nSh, "<BROWSER>", browser,)
	nSh = strings.ReplaceAll(nSh, "<TASK_MANAGER>", taskManager,)
	nSh = strings.ReplaceAll(nSh, "<SCREENPRT>", screenprt,)
	nSh = strings.ReplaceAll(nSh, "<HIDDEN_SCREENPRT>", hiddenScreenprt,)
	nSh = strings.ReplaceAll(nSh, "<DROPTERMINAL>", dropTerminal,)
	//Settings
	nSh = strings.ReplaceAll(nSh, "<TERMX>", termx,)
	nSh = strings.ReplaceAll(nSh, "<COMPOSITOR>", compositor,)
	nSh = strings.ReplaceAll(nSh, "<BARMODE>", barMode,)
	nSh = strings.ReplaceAll(nSh, "<WORKSPACE_LAYOUT>", workspaceLayout,)
	nSh = strings.ReplaceAll(nSh, "<LOCK_SCREEN>", lockScreen,)
	nSh = strings.ReplaceAll(nSh, "<POLKIT>", polkit,)
	//Font
	nSh = strings.ReplaceAll(nSh, "<FONT>", font,)
	nSh = strings.ReplaceAll(nSh, "<FONT_NAME>", fontName,)
	nSh = strings.ReplaceAll(nSh, "<FONT_SIZE>", fontSize,)
	nSh = strings.ReplaceAll(nSh, "<FONT_STYLES>", fontStyles,)
	//Theme
	nSh = strings.ReplaceAll(nSh, "<SEPARATOR_SYNBOL>", barSeparatorSynbol,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_MAIN>", colorMain,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_BORDER>", colorBorder,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_INACTIVE>", colorInactive,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_BACKGROUND>", colorBackground,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_TAB_BACKGROUND>", colorTabBackground,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_TXT_MAIN>", colorTxtMain,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_TXT_INACTIVE>", colorTxtInactive,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_TAB_TXT_INACTIVE>", colorTabTxtInactive,)

// Dunst resource
	dunstRc = strings.ReplaceAll(dunstRc,"<FONT>",dunstFont)
	dunstRc = strings.ReplaceAll(dunstRc,"<COLOR_BACKGROUND>",colorBackground)
	dunstRc = strings.ReplaceAll(dunstRc,"<COLOR_TAB_TXT_INACTIVE>",colorTabTxtInactive)
	dunstRc = strings.ReplaceAll(dunstRc,"<COLOR_TAB_BACKGROUND>",colorTabBackground)
	dunstRc = strings.ReplaceAll(dunstRc,"<COLOR_MAIN>",colorMain)
//N Runner
	//Font
	rofiColors = strings.ReplaceAll(rofiColors, "<FONT>", font,)
	rofiColors = strings.ReplaceAll(rofiColors, "<FONT_NAME>", fontName,)
	rofiColors = strings.ReplaceAll(rofiColors, "<FONT_SIZE>", fontSize,)
	rofiColors = strings.ReplaceAll(rofiColors, "<FONT_STYLES>", fontStyles,)
	//Theme
	rofiColors = strings.ReplaceAll(rofiColors, "<COLOR_MAIN>", colorMain,)
	rofiColors = strings.ReplaceAll(rofiColors, "<COLOR_BORDER>", colorBorder,)
	rofiColors = strings.ReplaceAll(rofiColors, "<COLOR_INACTIVE>", colorInactive,)
	rofiColors = strings.ReplaceAll(rofiColors, "<COLOR_BACKGROUND>", colorBackground,)
	rofiColors = strings.ReplaceAll(rofiColors, "<COLOR_TAB_BACKGROUND>", colorTabBackground,)
	rofiColors = strings.ReplaceAll(rofiColors, "<TXT_MAIN>", colorTxtMain,)
	rofiColors = strings.ReplaceAll(rofiColors, "<TXT_INACTIVE>", colorTxtInactive,)
	rofiColors = strings.ReplaceAll(rofiColors, "<TAB_TXT_INACTIVE>", colorTabTxtInactive,)
//Waybar
	//Font
	waybarStyle = strings.ReplaceAll(waybarStyle, "<FONT>", font,)
	waybarStyle = strings.ReplaceAll(waybarStyle, "<FONT_NAME>", fontName,)
	waybarStyle = strings.ReplaceAll(waybarStyle, "<FONT_SIZE>", fontSize,)
	waybarStyle = strings.ReplaceAll(waybarStyle, "<FONT_STYLES>", fontStyles,)
	//Theme
	waybarStyle = strings.ReplaceAll(waybarStyle, "<COLOR_MAIN>", colorMain,)
	waybarStyle = strings.ReplaceAll(waybarStyle, "<COLOR_BORDER>", colorBorder,)
	waybarStyle = strings.ReplaceAll(waybarStyle, "<COLOR_INACTIVE>", colorInactive,)
	waybarStyle = strings.ReplaceAll(waybarStyle, "<COLOR_BACKGROUND>", colorBackground,)
	waybarStyle = strings.ReplaceAll(waybarStyle, "<COLOR_TAB_BACKGROUND>", colorTabBackground,)
	waybarStyle = strings.ReplaceAll(waybarStyle, "<TXT_MAIN>", colorTxtMain,)
	waybarStyle = strings.ReplaceAll(waybarStyle, "<TXT_INACTIVE>", colorTxtInactive,)
	waybarStyle = strings.ReplaceAll(waybarStyle, "<TAB_TXT_INACTIVE>", colorTabTxtInactive,)

	os.WriteFile(mainConfig,[]byte(swayConfig),0755)
	os.WriteFile(rofiColorsFile,[]byte(rofiColors),0755)
	os.WriteFile(waybarStyleFile,[]byte(waybarStyle),0755)
	os.WriteFile(nShFile,[]byte(nSh),0755)
	os.WriteFile(dunstRcFile,[]byte(dunstRc),0755)

// Set defaults
	// fileManagerDesk := sh(0,"find", `/usr/share/applications/ -iname "*`+fileManager+`*"`)

	sh(0, "swaymsg","exec","update-alternatives","--set","x-terminal-emulator","/usr/bin/"+terminal)
	sh(0, "swaymsg","exec","update-alternatives","--set","www-browser","/usr/bin/"+browser)
	// sh(0, "swaymsg","xdg-mime","default",fileManagerDesk,"inode/directory")

//sway restart
	sh(0,"pkill","dunst")
	sh(0,"swaymsg", "exec --no-startup-id /etc/n-desktop/scripts/notifyer.sh")
	if ( restart == true) {
		sh(0,"swaymsg", "restart")
	}

	fmt.Println("-- Ok --")
}

func main() {
	switch mainArgs[0] {
		case "--push-config", "-pc":
			sh(0,"cp","-r","/etc/n-desktop",mainPath)
			sh(0,"chown","-r", userData.Username+":"+userData.Username, mainPath)
		case "--up-config", "-uc":
			fmt.Println("-- TO DO --")
		case "--switch-theme", "-sth":
			switch mainArgs[1] {
				case "-d", "--dark":
					themeMn("-switch-dark","")
				
				case "-l", "--light":
					themeMn("-switch-light","")
			}
		
		case "--set-gtk-light-theme", "--set-gtk-dark-theme",  "-gtklth", "-gtkdth", "--set-light-icons", "-sli", "--set-dark-icons", "-sdi", "--set-light-wallpaper","-slwpp", "--set-dark-wallpaper","-sdwpp", "--set-wallpaper-cmd","-swppc":
			themeMn(mainArgs[0],mainArgs[1])
		case "--restore-theme":
			themeMn("--restore-theme","")
		case "--wp-manager":
			currentWp, _:= exec.Command("sh",mainPath+"/scripts/cwp.sh").Output()
			str := string(currentWp[0])
			wpInt, _ := strconv.Atoi((str))
			switch mainArgs[1] {
				case "--next":
					wpInt = wpInt + 1
					if (wpInt > 1) {sh(0,"swaymsg","workspace",strconv.Itoa(int(wpInt)))}
				
				case "--prev":
					wpInt = wpInt - 1
					if (wpInt != 0) {sh(0,"swaymsg","workspace",strconv.Itoa(int(wpInt)))}
			}
		
		case "--list", "-l":
			config("-list","")
		
		case "--tui":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			sh(0,"st","-t","N Config Tool","bash",scripts+"/nde-tui.sh")
		
		case "--update", "-U":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			desktopUpdate(true)
		
		case "--reset-theme", "-rt":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			dbSh(0,"-rm","@config_color")
			dbSh(0,"-rm","@config")
			dbSh(0,"-rm","@config_font")
			desktopUpdate(true)
		
		case "--reset", "-r":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			dbSh(0,"-rm","@nde_"+mainArgs[1])
		
		case "--add-applet","+a":
			appletMn("-add",mainArgs[1],mainArgs[2])
		
		case "--del-applet","-a":
			appletMn("-del",mainArgs[1],"")
		
		case "--list-applets","-lA":
			appletMn("-list","","")
		
		case "--add-bindsym","+b":
			keyBindMn("-add",mainArgs[1],mainArgs[2],mainArgs[3:])
		
		case "--del-bindsym","-b":
			keyBindMn("-dell",mainArgs[1],mainArgs[2],mainArgs[3:])
		
		case "--menu":
			output, _:= exec.Command("bash",scripts+"nmenu.sh","--menu",mainArgs[1]).Output()
			fmt.Printf(string(output))
		
		case "--menu-run":
			output, _:= exec.Command("bash",scripts+"nmenu.sh","--run",mainArgs[1]).Output()
			fmt.Printf(string(output))
		
		case "--menu-input":
			output, _:= exec.Command("bash",scripts+"nmenu.sh","--input",mainArgs[1]).Output()
			fmt.Printf(string(output))
		
		case "--help", "-h":
			fmt.Printf(`-=- N OS Desktop Environment Configuration Tool -=-
~ MatheusNDDS : https://github.com/MatheusNDDS

	## Commands ##
	 --list, -l : List NDE configuration variables.
	 --update, -U : Update the desktop to apply changes.
	 --tui, -t : Open a terminal interface.
	 --help, -h : Show the help text.
	 
	 ## Theme and Wallpaper ##
	 --switch-theme -sth : Switch theme with the sub-argulents :
                        --dark, -d
                        --light, -l
	 
   --set-gtk-dark-theme, -gtkdth : Set dark gtk theme
   --set-gtk-light-theme, -gtklth : Set light gtk theme
   --set-light-wallpaper, -sdwpp : Set light theme wallpaper
   --set-dark-wallpaper, -slwpp : Set dark theme wallpaper 
	
	## Desktop customization ##
	 [Syntax]: n-desktop terminal=st
	 Configurations are declarative variables based on the “--list” command keys.

	## Applets ##
	 [Syntax]: n-desktop +a Applet_Name Main_Command exec/exec_always Full Command Line...
	 --add-applet, +a : Add a applet.
	 --del-applet, -a : Remove a applet, only requires the applet name.

	## Menus (On rework) ##
	 [Syntax]: n-desktop --menu "p=Custom_prompt op1 op2 opt3"
	 --menu : Normal options menu, return a option.
	 --menu-run : Program run menu, run a program.
	 --menu-input : Prompt menu, return the inserted text.

	To apply changes run “n-desktop --update” command.

			`)
		default:
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			for i:= 0; i < len(mainArgs); i++{
				dataOut := config("-set",mainArgs[i])
				fmt.Println("-- writed: "+dataOut)
			}
	}
}
