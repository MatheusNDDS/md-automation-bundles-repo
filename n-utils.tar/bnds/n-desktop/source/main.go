package main

import (
	"fmt"
	"os"
	"os/exec"
	"strconv"
	"strings"
)

var mainArgs = os.Args[1:]
const mainPath = "/etc/n-desktop/"
const appletsPath = mainPath+"system/applets/"
const bindsPath = mainPath+"system/binds/"
const mainConfig = mainPath+"main"
const scripts = mainPath+"scripts/"
const templates = mainPath+"/system/templates"
const nShFile = mainPath+"configs/sh"
const dunstRcFile = mainPath+"configs/dunstrc"

var nSh = `
#N Desktop
npath=/etc/n-desktop
nconfigs=$npath/configs
nscripts=$npath/scripts

#Themes:
color_main="<COLOR_MAIN>"
color_border="<COLOR_BORDER>"
color_inactive="<COLOR_INACTIVE>"
color_background="<COLOR_BACKGROUND>"
color_tab_background="<COLOR_TAB_BACKGROUND>"
color_tab_txt_inactive="<COLOR_TAB_TXT_INACTIVE>"
color_txt_main="<COLOR_TXT_MAIN>"
color_txt_inactive="<COLOR_TXT_INACTIVE>"

#Utilities:
termx="<TERMX>"
terminal="<TERMINAL>"
notifyer="<NOTIFYER>"
file_manager="<FILE_MANAGER>"
browser="<BROWSER>"
hidden_screenprt="<HIDDEN_SCREENPRT>"
task_manager="<TASK_MANAGER>"
screenprt="<SCREENPRT>"
dropterminal="<DROPTERMINAL>"
polkit="<POLKIT>"
separator_symbol="<SEPARATOR_SYNBOL>"
compositor="<COMPOSITOR>"

#Tools:
alias ndb="$nscripts/bmdb.sh"
shopt -s expand_aliases
`
// Read template files
var i3ConfigBuff , _ = os.ReadFile(templates+"/main")
var dunstRcBuff , _ = os.ReadFile(templates+"/dunstrc")

// Converts io into string type
var i3Config = string(i3ConfigBuff)
var dunstRc = string(dunstRcBuff)


func sh(doStdout byte,cmd string,args ...string)(output string){
	stdout, err := exec.Command(cmd, args...).Output()
	if doStdout == 1 {
		if err != nil {
			fmt.Println(err)
		}else{
			fmt.Printf(string(stdout))
		}
	}
	output = string(stdout[:])
return
}

func dbSh(doStdout byte,args ...string)(output string){
	// apiCall := []string{"-api","bmr"}
	// args = append(apiCall,args...)
	stdout, err := exec.Command(scripts+"/bmdb.sh", args...).Output()
	if doStdout == 1 {
		if err != nil {
			fmt.Println(err)
		}else{
			fmt.Printf(string(stdout))
		}
	}
	output = string(stdout)
return
}

func config(opt string, req string)(dataOut string){
	switch opt {
		case "-set":
			props := strings.Split(req, "=")
			if ( props[1] != "" ) {
				dbSh(0,"-srg","@nde_"+props[0],props[1])
				dataOut = props[0]+"="+props[1]
			}else{
				dbSh(0,"-rm","@nde_"+props[0])
			}
		case "-list":
			keys := dbSh(0, "-gal", "@nde_")
			keys = strings.ReplaceAll(keys, "-d @nde_", "",)
			fmt.Println(keys)
		case "-get":
			ref := dbSh(0, "-gd", "@nde_"+req)
			if ( ref != "" && ref[0:2] == "--" ) {
				dataOut = config("-get",string(ref[2:]))
			}else{
				dataOut = ref
			}
			dataOut = strings.ReplaceAll(dataOut,"\n", "")
	}
	return
}

func appletMn(opt string, applName string, mainCommand string, commandLine []string){
	commandStr := strings.Join(commandLine," ")
	switch opt {
		case "-add":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			if ( commandLine[0] != "exec" && commandLine[0] != "exec_always" ) {
				fmt.Println("appletMn::error \n The applet commannd line needs to start with “exec” or “exec_aways”, and can't be inserted inside strings.")
				return
			}

			dbSh(0,"-srg","@nde_appl_"+applName, mainCommand, commandStr)
			sh(0,"i3-msg", commandLine...)
			desktopUpdate(false)

			fmt.Println("applet “"+applName+"” added \n"+"Main Command : "+mainCommand, "\nCommand Line : ",commandLine)
		case "-del":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			applData := strings.Split(dbSh(0,"-gl", "@nde_appl_"+applName), " ")
			dbSh(0,"-rm",applData[1])
			sh(0,"pkill",applData[2])
			desktopUpdate(false)

			fmt.Println("applet “"+applName+"” deleted")
		case "-list":
			keys := dbSh(0, "-gal", "@nde_appl_")
			keys = strings.ReplaceAll(keys, "-d @nde_appl_", "> ",)
			fmt.Println(keys)
	}
}

func keyBindMn(opt string, bindScope string, bind string, commandLine []string){
	commandStr := strings.Join(commandLine," ")
	switch opt {
		case "-add":
			os.WriteFile(bindsPath+"/"+bindScope+"/"+bind,[]byte("bindsym "+bind+" "+commandStr),0777)
			desktopUpdate(false)
		case "-del":
			os.Remove(bindsPath+"/"+bindScope+"/"+bind)
			desktopUpdate(false)
		case "-list":
			//
	}

}

func desktopUpdate(restart bool){
	fmt.Print("\033[H\033[2J")
	fmt.Println(" Wait, Updating the desktop ...")

	applets := dbSh(0,"-gappl")
	configs := dbSh(0,"-gcfg")
	// strTest := false
	// fmt.Println(strTest)

	//Tools
	terminal := config("-get","terminal")
	notifyer := config("-get","nofifyer")
	fileManager := config("-get","file_manager")
	browser := config("-get","browser")
	screenprt := config("-get","screenprt")
	hiddenScreenprt := config("-get","hidden_screenprt")
	taskManager := config("-get","task_manager")
	dropTerminal := config("-get","dropterminal")
	//Settings
	termx := config("-get","termx")
	compositor := config("-get","compositor")
	barMode := config("-get","bar_mode")
	workspaceLayout := config("-get","workspace_layout")
	lockScreen := config("-get","lock_screen")
	focusFollowMouse := config("-get", "focus_follows_mouse")
	polkit := dbSh(0,"-gd", "@nde_polkit")
	//theme
	font := config("-get","font")
	dunstFont := strings.ReplaceAll(font,"pango:","")
	barSeparatorSynbol := config("-get","bar_separator_symbol")
	colorMain := config("-get","color_main")
	colorBorder := config("-get","color_border")
	colorInactive := config("-get","color_inactive")
	colorBackground := config("-get","color_background")
	colorTabBackground := config("-get","color_tab_background")
	colorTxtMain := config("-get","color_txt_main")
	colorTabTxtInactive := config("-get","color_tab_txt_inactive")
 	colorTxtInactive := config("-get","color_txt_inactive")
//Defaults
	//Tools
	//strTest = strings.Contain("terminal") ; if( strTest == false ){terminal = "stterm" ; config("-set", "terminal="+terminal)}
	if( terminal == "" ){terminal= "stterm" ; config("-set", "terminal="+terminal)}
	if( notifyer == "" ){notifyer= "/etc/n-desktop/scripts/notifyer.sh" ; config("-set", "notifyer="+notifyer)}
	if( fileManager == "" ){fileManager = "stterm mc" ; config("-set", "file_manager="+fileManager)}
	if( browser == "" ){browser = "stterm lynx www.google.com" ; config("-set", "browser="+browser)}
	if( taskManager == "" ){taskManager = "stterm htop" ; config("-set", "task_manager="+taskManager)}
	if( dropTerminal == "" ){dropTerminal = "" ; config("-set", "dropterminal="+dropTerminal)}
	// Settings
	if( termx == "" ){termx = "stterm" ; config("-set", "termx="+termx)}
	if( compositor == "" ){compositor = "picom --no-ewmh-fullscreen -b --config /etc/n-desktop/configs/picom" ; config("-set", "compositor="+compositor)}
	if( barMode == "" ){barMode = "dock" ; config("-set", "bar_mode="+barMode)}
	if( barSeparatorSynbol == "" ){barSeparatorSynbol = "," ; config("-set", "bar_separator_symbol="+barSeparatorSynbol)}
	if( workspaceLayout == "" ){workspaceLayout= "tabbed" ; config("-set", "workspace_layout="+workspaceLayout)}
	if( lockScreen == "" ){lockScreen= "xsecurelock" ; config("-set", "lock_screen="+lockScreen)}
	if( focusFollowMouse == "" ){focusFollowMouse= "yes" ; config("-set", "focus_follows_mouse="+focusFollowMouse)}
	//themes
	if( font == "" ){font = "pango:Dejavu Sans Mono 9" ; config("-set", "font="+font)}
	if( colorMain == "" ){colorMain = "#ffffff" ; config("-set", "color_main="+colorMain)}
	if( colorInactive == "" ){colorInactive = "#4c4c4c" ; config("-set", "color_inactive="+colorInactive)}
	if( colorBackground == "" ){colorBackground = "#000000" ; config("-set", "color_background="+colorBackground)}
	if( colorTabBackground == "" ){colorTabBackground = "#1a1a1a" ; config("-set", "color_tab_background="+colorTabBackground)}
	if( colorBorder == "" ){colorBorder = colorBackground ; config("-set", "color_border="+colorBorder)}
	if( colorTxtMain == "" ){colorTxtMain = "#000000" ; config("-set", "color_txt_main="+colorTxtMain)}
	if( colorTxtInactive == "" ){colorTxtInactive= "#ffffff" ; config("-set", "color_txt_inactive="+colorTxtInactive)}
	if( colorTabTxtInactive == "" ){colorTabTxtInactive = colorTxtInactive ; config("-set", "color_tab_txt_inactive="+colorTabTxtInactive)}

//i3 Config builder
	//Tools
	i3Config = strings.ReplaceAll(i3Config, "<TERMINAL>", terminal,)
	i3Config = strings.ReplaceAll(i3Config, "<NOTIFYER>", notifyer,)
	i3Config = strings.ReplaceAll(i3Config, "<FILE_MANAGER>", fileManager,)
	i3Config = strings.ReplaceAll(i3Config, "<BROWSER>", browser,)
	i3Config = strings.ReplaceAll(i3Config, "<TASK_MANAGER>", taskManager,)
	i3Config = strings.ReplaceAll(i3Config, "<SCREENPRT>", screenprt,)
	i3Config = strings.ReplaceAll(i3Config, "<HIDDEN_SCREENPRT>", hiddenScreenprt,)
	i3Config = strings.ReplaceAll(i3Config, "<DROPTERMINAL>", dropTerminal,)
	//Settings
	i3Config = strings.ReplaceAll(i3Config, "<TERMX>", termx,)
	i3Config = strings.ReplaceAll(i3Config, "<COMPOSITOR>", compositor,)
	i3Config = strings.ReplaceAll(i3Config, "<BARMODE>", barMode,)
	i3Config = strings.ReplaceAll(i3Config, "<WORKSPACE_LAYOUT>", workspaceLayout,)
	i3Config = strings.ReplaceAll(i3Config, "<LOCK_SCREEN>", lockScreen,)
	i3Config = strings.ReplaceAll(i3Config, "<POLKIT>", polkit,)
	i3Config = strings.ReplaceAll(i3Config, "<FOCUS_FOLLOW_MOUSE>", focusFollowMouse,)
	//Theme
	i3Config = strings.ReplaceAll(i3Config, "<FONT>", font,)
	i3Config = strings.ReplaceAll(i3Config, "<SEPARATOR_SYNBOL>", barSeparatorSynbol,)
	i3Config = strings.ReplaceAll(i3Config, "<COLOR_MAIN>", colorMain,)
	i3Config = strings.ReplaceAll(i3Config, "<COLOR_BORDER>", colorBorder,)
	i3Config = strings.ReplaceAll(i3Config, "<COLOR_INACTIVE>", colorInactive,)
	i3Config = strings.ReplaceAll(i3Config, "<COLOR_BACKGROUND>", colorBackground,)
	i3Config = strings.ReplaceAll(i3Config, "<COLOR_TAB_BACKGROUND>", colorTabBackground,)
	i3Config = strings.ReplaceAll(i3Config, "<TXT_MAIN>", colorTxtMain,)
	i3Config = strings.ReplaceAll(i3Config, "<TXT_INACTIVE>", colorTxtInactive,)
	i3Config = strings.ReplaceAll(i3Config, "<TAB_TXT_INACTIVE>", colorTabTxtInactive,)
	//Applets
	i3Config = strings.ReplaceAll(i3Config, "<NDE_APPLETS>", applets,)
	i3Config = strings.ReplaceAll(i3Config, "<NDE_CONFIGS>", configs,)
	//Embedded	
	i3Config = strings.ReplaceAll(i3Config, "<NSCRIPTS>", scripts,)

//Shell Variables
	nSh = strings.ReplaceAll(nSh, "<TERMINAL>", terminal,)
	nSh = strings.ReplaceAll(nSh, "<NOTIFYER>", notifyer,)
	nSh = strings.ReplaceAll(nSh, "<FILE_MANAGER>", fileManager,)
	nSh = strings.ReplaceAll(nSh, "<BROWSER>", browser,)
	nSh = strings.ReplaceAll(nSh, "<TASK_MANAGER>", taskManager,)
	nSh = strings.ReplaceAll(nSh, "<SCREENPRT>", screenprt,)
	nSh = strings.ReplaceAll(nSh, "<HIDDEN_SCREENPRT>", hiddenScreenprt,)
	nSh = strings.ReplaceAll(nSh, "<DROPTERMINAL>", dropTerminal,)
	//Settings
	nSh = strings.ReplaceAll(nSh, "<TERMX>", termx,)
	nSh = strings.ReplaceAll(nSh, "<COMPOSITOR>", compositor,)
	nSh = strings.ReplaceAll(nSh, "<BARMODE>", barMode,)
	nSh = strings.ReplaceAll(nSh, "<WORKSPACE_LAYOUT>", workspaceLayout,)
	nSh = strings.ReplaceAll(nSh, "<LOCK_SCREEN>", lockScreen,)
	nSh = strings.ReplaceAll(nSh, "<POLKIT>", polkit,)
	//Theme
	nSh = strings.ReplaceAll(nSh, "<FONT>", font,)
	nSh = strings.ReplaceAll(nSh, "<SEPARATOR_SYNBOL>", barSeparatorSynbol,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_MAIN>", colorMain,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_BORDER>", colorBorder,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_INACTIVE>", colorInactive,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_BACKGROUND>", colorBackground,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_TAB_BACKGROUND>", colorTabBackground,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_TXT_MAIN>", colorTxtMain,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_TXT_INACTIVE>", colorTxtInactive,)
	nSh = strings.ReplaceAll(nSh, "<COLOR_TAB_TXT_INACTIVE>", colorTabTxtInactive,)

// Dunst resource
	dunstRc = strings.ReplaceAll(dunstRc,"<FONT>",dunstFont)
	dunstRc = strings.ReplaceAll(dunstRc,"<COLOR_BACKGROUND>",colorBackground)
	dunstRc = strings.ReplaceAll(dunstRc,"<TAB_TXT_INACTIVE>",colorTabTxtInactive)
	dunstRc = strings.ReplaceAll(dunstRc,"<COLOR_TAB_BACKGROUND>",colorTabBackground)
	dunstRc = strings.ReplaceAll(dunstRc,"<COLOR_MAIN>",colorMain)

	os.WriteFile(mainConfig,[]byte(i3Config),0755)
	os.WriteFile(nShFile,[]byte(nSh),0755)
	os.WriteFile(dunstRcFile,[]byte(dunstRc),0755)

// Set defaults sudo update-alternatives --set
	sh(0, "sudo", "update-alternatives", "--set", "x-terminal-emulator", "/usr/bin/"+terminal)

//i3 restart
	sh(0,"pkill","dunst")
	sh(0,"i3-msg", "exec --no-startup-id /etc/n-desktop/scripts/notifyer.sh")
	if ( restart == true) {
		sh(0,"i3-msg", "restart")
	}

	fmt.Println("-- Ok --")
	fmt.Print("\033[H\033[2J")
}

func main() {
	switch mainArgs[0] {
		case "--wp-manager":
			currentWp, _:= exec.Command("sh",mainPath+"/scripts/cwp.sh").Output()
			str := string(currentWp[0])
			wpInt, _ := strconv.Atoi((str))
			switch mainArgs[1] {
				case "--next":
					wpInt = wpInt + 1
					if (wpInt > 1) {sh(0,"i3-msg","workspace",strconv.Itoa(int(wpInt)))}
				case "--prev":
					wpInt = wpInt - 1
					if (wpInt != 0) {sh(0,"i3-msg","workspace",strconv.Itoa(int(wpInt)))}
			}
		case "--list", "-l":
			config("-list","")
		case "--tui":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			sh(0,"st","-t","N Config Tool","bash",scripts+"/nde-tui.sh")
		case "--update", "-U":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			desktopUpdate(true)
		case "--reset-theme", "-rt":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			dbSh(0,"-rm","@nde_color")
			dbSh(0,"-rm","@nde_txt")
			dbSh(0,"-rm","@nde_font")
			desktopUpdate(true)
		case "--reset", "-r":
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			dbSh(0,"-rm","@nde_"+mainArgs[1])
		case "--add-applet","+a":
			appletMn("-add",mainArgs[1],mainArgs[2],mainArgs[3:])
		case "--del-applet","-a":
			appletMn("-del",mainArgs[1],"",nil)
		case "--list-applets","-lA":
			appletMn("-list","","",nil)
		case "--add-bindsym","+b":
			keyBindMn("-add",mainArgs[1],mainArgs[2],mainArgs[3:])
		case "--del-bindsym","-b":
			keyBindMn("-dell",mainArgs[1],mainArgs[2],mainArgs[3:])
		case "--menu":
			output, _:= exec.Command("bash",scripts+"dmenu.sh","--menu",mainArgs[1]).Output()
			fmt.Printf(string(output))
		case "--menu-run":
			output, _:= exec.Command("bash",scripts+"dmenu.sh","--run",mainArgs[1]).Output()
			fmt.Printf(string(output))
		case "--menu-input":
			output, _:= exec.Command("bash",scripts+"dmenu.sh","--input",mainArgs[1]).Output()
			fmt.Printf(string(output))
		case "--help", "-h":
			fmt.Printf(`-=- N OS Desktop Environment Configuration Tool -=-
~ MatheusNDDS : https://github.com/MatheusNDDS

	## Commands ##
	 --list, -l : List NDE configuration variables.
	 --update, -U : Update the desktop to apply changes.
	 --tui, -t : Open a terminal interface.
	 --help, -h : Show the help text.

	## Desktop customization ##
	 [Syntax]: n-desktop terminal=st
	 Configurations are declarative variables based on the “--list” command keys.
	
	## Applets ##
	 [Syntax]: n-desktop +a Applet_Name Main_Command exec/exec_always Full Command Line...
	 --add-applet, +a : Add a applet.
	 --del-applet, -a : Remove a applet, only requires the applet name.
	
	## Menus ##
	 [Syntax]: n-desktop --menu "p=Custom_prompt op1 op2 opt3"
	 --menu : Normal options menu, return a option.
	 --menu-run : Program run menu, run a program.
	 --menu-input : Prompt menu, return the inserted text.

	To apply changes run “n-desktop --update” command.

			`)
		default:
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			for i:= 0; i < len(mainArgs); i++{
				dataOut := config("-set",mainArgs[i])
				fmt.Println("-- writed: "+dataOut)
			}
	}
}
