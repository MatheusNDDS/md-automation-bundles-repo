## Novas features

### CONFIG: carregar arquivo local
> Adicionar a capacidade de carregar os argumentos das variáveis direto de um arquivo de texto.

## Melhorias

### CONFIG, UPDATE:
> Otimizar as operações com o BMR, limitando-as apenas para as configurações informadas

### MAIN:
> Melhorar a sintaxe dos argumentos

## Correções

