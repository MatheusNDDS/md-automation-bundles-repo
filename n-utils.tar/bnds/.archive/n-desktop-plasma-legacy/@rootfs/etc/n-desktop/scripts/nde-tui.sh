source /etc/bmn/init ; source /etc/n-desktop/configs/sh
alias tdb="bmn -api bmr db=$h/.thindb"
shopt -s expand_aliases

menu_size=(40 100 40)
header=( --backtitle "Configurações do N Desktop / use Ctrl + c para sair")
main=(
    "${header[@]}" --no-tags --no-cancel
    --title "N Config"
    --menu "Options" 0 0 0
        tools 'Tools'
        settings 'Settings'
        applets 'N Applets'
        theme 'Theme'
        wallpaper 'Wallpapers'
)
declare -A thin_cmd_tr
thin_cmd_tr["Light"]="-slw:@thin_wpl"
thin_cmd_tr["Dark"]="-sdw:@thin_wpd"
thin_cmd_tr["Command"]="-swc:@thin_2wpc"
theme_keys=(
    font
    bar_separator_symbol
    color_main
    color_border
    color_tab_background
    color_background
    color_inactive
    color_txt_main
    color_txt_inactive
    color_tab_txt_inactive )

tools_keys=(
    terminal
    drop_terminal
    filemanager
    browser
    task_manager
    screenprt
    hidden_screenprt )

settings_keys=(
    workspace_layout
    focus_follows_mouse
    bar_mode
    lock_screen
    compositor
    notifyer
    base
    polkit
    vdesktop
    termx )

[[ $UID != 0 ]] && exit 1

while true
do
    opt=$(-btk "${main[@]}")
    has_updated=0
    case $opt in
    tools)
        while true
        do
            tools_menu=( "${header[@]}" --title "Tools" --inputmenu "Desktop default programs." ${menu_size[@]} )
            for i in ${tools_keys[@]}
            do
                tools_menu+=($i "$(ndb -gd @config_$i)")
#                 -prt ${tools_menu[@]}
            done
            opt=($(-btk "${tools_menu[@]}"))
            [[ ${opt[0]} = "RENAMED" ]] && n-desktop ${opt[1]}="${opt[*]:2}" && has_updated=1
            [[ $? = 1 ]] && break
        done
    ;;
    settings)
        while true
        do
            settings_menu=( "${header[@]}" --title "Settings" --inputmenu "Desktop general settings." ${menu_size[@]} )
            for i in ${settings_keys[@]}
            do
                settings_menu+=($i "$(ndb -gd @config_$i)")
#                 -prt ${tools_menu[@]}
            done
            opt=($(-btk "${settings_menu[@]}"))
            [[ ${opt[0]} = "RENAMED" ]] && n-desktop ${opt[1]}="${opt[*]:2}" && has_updated=1
            [[ $? = 1 ]] && break
        done
    ;;
    theme)
        while true
        do
            theme_menu=( "${header[@]}" --title "Theme" --inputmenu "Desktop appearance." ${menu_size[@]} )
            for i in ${theme_keys[@]}
            do
                theme_menu+=($i "$(ndb -gd @config_$i)")
#                 -prt ${theme_menu[@]}
            done
            nde_args=($(-btk "${theme_menu[@]}"))
            [[ ${nde_args[0]} = "RENAMED" ]] && n-desktop ${nde_args[1]}="${nde_args[*]:2}" && has_updated=1
            [[ $? = 1 ]] && break
        done
    ;;
    wallpaper)
        while true
        do
            wpp=(
                "${header[@]}"
                --title "Wallpapers"
                --inputmenu "Options" ${menu_size[@]}
                Light "$(tdb -gd @thin_wpl)"
                Dark "$(tdb -gd @thin_wpd)"
                Command "$(tdb -gd @thin_2wpc)"
            )
            out=($(-btk "${wpp[@]}"))
            op_data=($(echo ${thin_cmd_tr[${out[1]}]} | tr ":" " "))
            [[ ${out[0]} = "RENAMED" && ! -z ${thin_cmd_tr[${out[1]}]} ]] && echo ${thin_cmd_tr[${out[1]}]} #echo thin ${op_data[0]} ${out[*]:2}
            [[ $? = 1 ]] && break
        done
    ;;
    applets)
        appl_keys=($(ndb -gl @applet_ | cut -d' ' -f 2))
        appl_names=(${appl_keys[@]//"@applet_"/})
        appl_menu_itens=($(for appl in ${appl_names[@]};do echo $appl $appl;done))
        echo ${appl_menu_itens[2]}
        while true
        do
            appl_menu=(
                "${header[@]}" --no-tags
                --title "N Applets"
                --menu "Desktop embeded programs, cam provide funcionality and tray." 0 0 0
                ${appl_menu_itens[@]}
            )
            app_form=(
            		"${header[@]}"
            		--title "APPLET NAME"
            )
            -btk "${appl_menu[@]}"
            [[ $? = 1 ]] && break
        done
    ;;
    esac
    [[ $has_updated = 1 ]] && n-desktop --update
done
