module main

go 1.22.7

toolchain go1.22.9

require github.com/richardwilkes/unison v0.75.1

require (
	github.com/adrg/xdg v0.5.0 // indirect
	github.com/disintegration/imaging v1.6.2 // indirect
	github.com/dustin/go-humanize v1.0.1 // indirect
	github.com/ebitengine/purego v0.8.0 // indirect
	github.com/evilsocket/islazy v1.11.0 // indirect
	github.com/go-gl/gl v0.0.0-20231021071112-07e5d0ea2e71 // indirect
	github.com/go-gl/glfw/v3.3/glfw v0.0.0-20240506104042-037f3cc74f2a // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/hashicorp/golang-lru/v2 v2.0.1 // indirect
	github.com/klauspost/cpuid/v2 v2.2.8 // indirect
	github.com/kr/text v0.2.0 // indirect
	github.com/lafriks/go-svg v0.5.1-0.20240818203135-3a6c390fc116 // indirect
	github.com/mat/besticon/v3 v3.18.0 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/ncruces/go-strftime v0.1.9 // indirect
	github.com/pkg/term v1.1.0 // indirect
	github.com/remyoudompheng/bigfft v0.0.0-20230129092748-24d4a6f8daec // indirect
	github.com/richardwilkes/json v0.3.0 // indirect
	github.com/richardwilkes/toolbox v1.121.0 // indirect
	github.com/yuin/goldmark v1.7.8 // indirect
	github.com/zeebo/xxh3 v1.0.2 // indirect
	golang.org/x/exp v0.0.0-20241009180824-f66d83c29e7c // indirect
	golang.org/x/image v0.21.0 // indirect
	golang.org/x/net v0.30.0 // indirect
	golang.org/x/sys v0.26.0 // indirect
	golang.org/x/text v0.19.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
	modernc.org/fileutil v1.3.0 // indirect
	modernc.org/fsm v1.2.1 // indirect
	modernc.org/gc/v3 v3.0.0-20230512134359-466b49aa80e0 // indirect
	modernc.org/knuth v0.5.1 // indirect
	modernc.org/libX11 v0.11.2 // indirect
	modernc.org/libXau v0.9.2 // indirect
	modernc.org/libXdmcp v0.12.0 // indirect
	modernc.org/libXft v0.10.0 // indirect
	modernc.org/libXrender v0.9.0 // indirect
	modernc.org/libbsd v0.11.1 // indirect
	modernc.org/libc v1.61.0 // indirect
	modernc.org/libexpat v0.10.2 // indirect
	modernc.org/libfontconfig v0.8.2 // indirect
	modernc.org/libfreetype v0.9.1 // indirect
	modernc.org/libmd v0.12.0 // indirect
	modernc.org/libtcl9.0 v0.14.0 // indirect
	modernc.org/libtk9.0 v0.13.0 // indirect
	modernc.org/libxcb v0.11.0 // indirect
	modernc.org/libz v0.16.4 // indirect
	modernc.org/mathutil v1.6.0 // indirect
	modernc.org/memory v1.8.0 // indirect
	modernc.org/ngrab v0.1.0 // indirect
	modernc.org/rec v0.2.0 // indirect
	modernc.org/regexp v1.7.3 // indirect
	modernc.org/sortutil v1.2.0 // indirect
	modernc.org/strutil v1.2.0 // indirect
	modernc.org/tcl9.0 v0.15.0 // indirect
	modernc.org/tk9.0 v0.48.0 // indirect
	modernc.org/token v1.1.0 // indirect
)
