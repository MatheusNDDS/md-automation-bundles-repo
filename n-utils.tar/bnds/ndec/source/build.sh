export PATH=$PATH:/usr/local/go/bin
go build main.go
[[ $? = 0 ]] && mv main ../rootfs/usr/bin/ndec || exit 1
[[ $1 = 'i' ]] && sudo bmn -di ../../ndec
