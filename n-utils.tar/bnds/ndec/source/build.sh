export PATH=$PATH:/usr/local/go/bin
go build ndec.go
[[ $? = 0 ]] && mv ndex ../rootfs/usr/bin/ || exit 1
[[ $1 = 'i' ]] && sudo bmn -di ../../ndec
