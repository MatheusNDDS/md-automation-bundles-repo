export PATH=$PATH:/usr/local/go/bin
go build bdecfg.go
[[ $? = 0 ]] && mv bdecfg ../rootfs/usr/bin/ || exit 1
[[ $1 = 'i' ]] && sudo bmn -di ../../bdecfg
