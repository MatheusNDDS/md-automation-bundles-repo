#!/usr/bin/bash
## Data
xrandr_conf=($(bmn -rd @res))
xdisplay="${xrandr_conf[0]}"
xconfname="${xrandr_conf[1]}"

## Set resolution
case $1 in
	-c|--configure)
		sudo bash /etc/res-cfg res-cfg port &> /dev/null
	;;
	-h|--help)
		echo -e "[commands]:\n use only “set-res” to apply\n -c,--configure : Reconfigure resolution\n -h,--help : Print help text"
	;;
	*)
		if [ ! -z $xrandr_conf ]
		then
			xrandr --newmode ${xrandr_conf[*]:1} &> /dev/null
			xrandr --addmode $xdisplay $xconfname
			xrandr --output $xdisplay --mode $xconfname
		fi
	;;
esac
