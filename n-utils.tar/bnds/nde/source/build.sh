export PATH=$PATH:/usr/local/go/bin
go build nde.go
[[ $? = 0 ]] && mv nde ../rootfs/usr/bin/ || exit 1
[[ $1 = 'i' ]] && sudo bmn -di ../../nde
