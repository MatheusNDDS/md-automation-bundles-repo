export PATH=$PATH:/usr/local/go/bin
go build nde-cfg.go
[[ $? = 0 ]] && mv nde-cfg ../rootfs/usr/bin/ || exit 1
[[ $1 = 'i' ]] && sudo bmn -di ../../nde-cfg
