#!/bin/bash
case $* in
	"")
		tbsm --silent
	;;
	"-r")
		notify-send "N.OS Session" "<b><i><u>Reiniciando...</u></i></b>" &
		systemctl reboot -i
	;;
	"-s")
		notify-send "N.OS Session" "<b><i><u>Suspendendo...</u></i></b>" &
		systemctl suspend -i
		[ -z $DISPLAY ] && vlock
	;;
	"-o")
		notify-send "N.OS Session" "<b><i><u>Desligando...</u></i></b>" &
		systemctl poweroff -i
	;;
	"-H")
		echo -e "[Commands]\n nº: Start a Xorg or Wayland  session.\n -r: Reboot\n -s: Suspend\n -o: Power off\n -H: N-SS Help"
	;;
	*)
		[ $1 != '--help' ] && clear ; exec tbsm $* &> /dev/null || tbsm $*
	;;
esac
