export PATH=$PATH:/usr/local/go/bin
name="n-config"
go build main.go
[[ $? = 0 ]] && mv main ../rootfs/usr/bin/$name || exit 1
[[ $1 = 'i' ]] && sudo bmn -di ../../$name
