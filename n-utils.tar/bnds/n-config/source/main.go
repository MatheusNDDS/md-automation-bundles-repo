package main

import (
	"fmt"
	"os"
	"os/exec"
	"strings"
)

var mainArgs = os.Args[1:]

func sh(doStdout byte,cmd string,args ...string)(output string){
	stdout, err := exec.Command(cmd, args...).Output()
	if doStdout == 1 {
		if err != nil {
			fmt.Println(err)
		}else{
			fmt.Printf(string(stdout))
		}
	}
	output = string(stdout)
return
}

func dbSh(doStdout byte,args ...string)(output string){
	apiCall := []string{"-api","bmr"}
	args = append(apiCall,args...)
	stdout, err := exec.Command("bmn", args...).Output()
	if doStdout == 1 {
		if err != nil {
			fmt.Println(err)
		}else{
			fmt.Printf(string(stdout))
		}
	}
	output = string(stdout)
return
}

func config(opt string, req string){
	switch opt {
		case "-set":
			props := strings.Split(req, "=")
			dbSh(0,"-srg","@nde_"+props[0],props[1])
		case "-list":
			dbSh(1,"-glf","@nde_")
	}
}

func main() {
	switch mainArgs[0] {
		case "--list":
			config("-list","")
		default:
			if os.Getuid() != 0 {fmt.Println("-- Require ROOT --");return}
			config("-set",mainArgs[0])
	}
}
