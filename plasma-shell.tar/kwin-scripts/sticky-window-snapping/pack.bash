#!/bin/bash

zip -r sticky-window-snapping.kwinscript contents gpl-2.0.txt metadata.desktop
