echo $*
