export PATH=$PATH:/usr/local/go/bin
name="nebula-theme"
npath="etc/$name"

go build main.go
[[ $? = 0 ]] && rm -rf ../@rootfs/usr/bin/$name && mv main ../@rootfs/usr/bin/$name || exit 1
case $1 in 
	'-i')
		sudo bmn -di ../../$name
	;;
	'-b')
		sudo cp -r ../@rootfs/usr/bin/$name /bin/$name
		sudo cp -r ../@rootfs/usr /
	;;
	'-h'|'--help')
		echo "
		-b : Direct build
		-i : Install with BMN
		"
	;;
	*)
		echo "
		-b : Direct build and files update
		-i : Install with BMN
		"
	;;
esac
