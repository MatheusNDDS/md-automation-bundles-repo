package main
import (
	"fmt"
	"strconv"
	"os"
)
// Hex to 255 RGB converter, Huge thanks to https://github.com/CraigChilds94
type Hex string
type RGB struct {
	Red   uint8
	Green uint8
	Blue  uint8
}
func (h Hex) toRGB() (RGB, error) {
	return Hex2RGB(h)
}
func Hex2RGB(hex Hex) (RGB, error) {
	var rgb RGB
	values, err := strconv.ParseUint(string(hex), 16, 32)

	if err != nil {
		return RGB{}, err
	}
	rgb = RGB{
		Red:   uint8(values >> 16),
		Green: uint8((values >> 8) & 0xFF),
		Blue:  uint8(values & 0xFF),
	}
	return rgb, nil
}


// Templates buffer
var DarkBackgroundBuff, _ = os.ReadFile("~/.nebula-theme/Dark/background")
var LightBackgroundBuff, _ = os.ReadFile("~/.nebula-theme/Light/background")

// Temnplates String
var DarkBackground = string(DarkBackgroundBuff)
var LightBackground = string(LightBackgroundBuff)

func main ()  {
	// nebula-theme -d accent=#ffffff background:#000000
	var args = os.Args
	switch args[1] {
		case "--dark","-d":
			switch args[2] {
				case "background","bg":
					fmt.Print("Dark background selected")
				case "accent","ac":
					fmt.Println("Dark main selected")
			}
		case "--light","-l":
			switch args[2] {
				case "background", "bg":
					fmt.Print("Light background selected")
				case "accent", "ac":
					fmt.Println("Light main selected")
			}
		default:
			fmt.Print("Nothing to do...")

	}
	fmt.Println(args)
	rgb1, _ := Hex2RGB(Hex("FF0000"))
	rgb2, _ := Hex2RGB(Hex("00FF00"))
	rgb3, _ := Hex2RGB(Hex("0000FF"))

	fmt.Println(fmt.Sprintf("%d,%d,%d", rgb1.Red, rgb2.Green, rgb3.Blue))
}
