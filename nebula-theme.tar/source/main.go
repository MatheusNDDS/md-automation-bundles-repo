package main

import (
	"fmt"
	"os"
	"os/exec"
	"os/user"
	"strconv"
	"strings"
)
var userData , _ = user.Current()
var userHome = "/home/"+userData.Username
var dbPath = userHome+"/.nebula-theme/db"

//Dark background theme file
var darkBackgroundBuff, _ = os.ReadFile(userHome+"/.nebula-theme/dark/background")
var darkBackground = string(darkBackgroundBuff)
var darkBackgroundPath = userHome+"/.config/cosmic/com.system76.CosmicTheme.Light/v1/background"

//Light background theme file
var lightBackgroundBuff, _ = os.ReadFile(userHome+"/.nebula-theme/light/background")
var lightBackground = string(lightBackgroundBuff)
var lightBackgroundPath = userHome+"/.config/cosmic/com.system76.CosmicTheme.Dark/v1/background"


// Hex to 255 RGB converter, Huge thanks to https://github.com/CraigChilds94
type Hex string
func goSh(doStdout byte,cmd string,args ...string)(output string){
	stdout, err := exec.Command(cmd, args...).Output()
	if doStdout == 1 {
		if err != nil {
			fmt.Println(err)
		}else{
			fmt.Printf(string(stdout))
		}
	}
	output = string(stdout)
	return
}

func dbSh(doStdout byte,args ...string)(output string){
	stdout, err := exec.Command("/usr/bin/bmr", args...).Output()
	if doStdout == 1 {
		if err != nil {
			fmt.Println(err)
		}else{
			fmt.Printf(string(stdout))
		}
	}
	output = string(stdout)
	return
}

func config(opt string, req string)(dataOut string){
	switch opt {
		case "-set":
			props := strings.Split(req, "=")
			if ( props[1] != "" ) {
				dbSh(0,dbPath,"-srg","@nte_"+props[0]+" "+props[1])
				dataOut = props[0]+"="+props[1]
			}else{
				dbSh(0,dbPath,"-rm","@nte_"+props[0])
			}
		case "-list":
			keys := dbSh(0,dbPath,"-gal", "@nte_")
			keys = strings.ReplaceAll(keys, "-d @nte_", "")
			dataOut = keys
			fmt.Println(keys)
		case "-get":
			dataOut = dbSh(0,dbPath,"-gd", "@nte_"+req)
			dataOut = strings.ReplaceAll(dataOut,"\n", "")
	}
	return
}
func getColors(theme string) (accentColor RGB, backgroundColor RGB){
	themeString := strings.Split(config("-list",theme), "\n")
	fmt.Println(themeString)

	for i := 0; i < len(themeString); i++ {
		themeProps := strings.Split(themeString[i]," ")
		fmt.Println(themeProps)
		themeMetadata := strings.Split(themeProps[0],"_")
		colorHex := themeProps[1]

		switch themeMetadata[1] {
			case "background":
				backgroundColor, _ = Hex2RGB(Hex(colorHex))
			case "accent":
				accentColor, _ = Hex2RGB(Hex(colorHex))
		}
	}

	return
}


func processTheme( theme string, props []string){
	//Get the type RGB colors
	accentColor, backgroundColor := getColors(theme)
	backgroundColorString := fmt.Sprintf("red: %d, green: %d, blue: %d",backgroundColor.Red, backgroundColor.Green, backgroundColor.Blue)
	accentColorString := fmt.Sprintf("red: %d, green: %d, blue: %d",accentColor.Red, accentColor.Green, accentColor.Blue)

	// Update the theme in database
	for i := 0; i < len(props); i++ {
		prop := strings.Split(props[i], "=")
		config("-set", theme+"_"+prop[0]+"="+prop[1])
	}

	switch theme {
		case "dark":
			// Background
			darkBackground = strings.ReplaceAll(darkBackground,"<COLOR_BG>", backgroundColorString)
			//Accent
			darkBackground = strings.ReplaceAll(darkBackground,"<COLOR_ACCENT>", accentColorString)
			os.WriteFile("/home/md/.config/cosmic/com.system76.CosmicTheme.Light/v1/background",[]byte(darkBackground),0755)
		case "light":
			// Background
			lightBackground = strings.ReplaceAll(lightBackground,"<COLOR_BG>", backgroundColorString)
			//Accent
			lightBackground = strings.ReplaceAll(lightBackground,"<COLOR_ACCENT>", accentColorString)

			os.WriteFile(lightBackgroundPath,[]byte(lightBackground),0755)
	}



}

func main() {
	// nebula-theme -d accent=#ffffff background=#000000
	args := os.Args
	fmt.Println(strings.Split(config("-list","dark"), "\n"))
	switch args[1] {
		case "--dark","-d":
			processTheme("dark", args[2:])
		case "--light","-l":
			processTheme("light", args[2:])
		default:
			fmt.Print("Nothing to do...")

	}
}
