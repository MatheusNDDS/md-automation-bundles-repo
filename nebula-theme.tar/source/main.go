package main

import (
	"fmt"
	"os"
	"os/exec"
	"os/user"
	"strings"
)

var userData , _ = user.Current()
var userHome = "/home/"+userData.Username
var mainPath = userHome+"/.nebula-theme"
var dbPath = mainPath+"/db"
var darkThemePath = mainPath+"/dark/"
var lightThemePath = mainPath+"/light/"

//Theme files map
var darkThemeFiles = [...]string{
	darkThemePath+"/background",
}
var lightThemeFiles = [...]string{
	lightThemePath+"/background",
}

// Hex to 255 RGB converter, Huge thanks to https://github.com/CraigChilds94
type Hex string
func goSh(doStdout byte,cmd string,args ...string)(output string){
	stdout, err := exec.Command(cmd, args...).Output()
	if doStdout == 1 {
		if err != nil {
			fmt.Println(err)
		}else{
			fmt.Printf(string(stdout))
		}
	}
	output = string(stdout[:])
	return
}

func dbSh(doStdout byte,args ...string)(output string){
	stdout, err := exec.Command("/usr/bin/bmr", args...).Output()
	if doStdout == 1 {
		if err != nil {
			fmt.Println(err)
		}else{
			fmt.Printf(string(stdout))
		}
	}
	output = string(stdout)
	return
}

func config(opt string, req string)(dataOut string){
	switch opt {
		case "-set":
			props := strings.Split(req, "=")
			if ( props[1] != "" ) {
				dbSh(0,"db="+dbPath,"-srg","@nte_"+props[0]+" "+props[1])
				dataOut = props[0]+"="+props[1]
			}else{
				dbSh(0,"db="+dbPath,"-rm","@nte_"+props[0])
			}
		case "-list":
			keys := dbSh(0,"db="+dbPath,"-gal", "@nte_")
			keys = strings.ReplaceAll(keys, "-d @nte_", "")
			dataOut = keys
			fmt.Println(keys)
		case "-get":
			dataOut = dbSh(0,"db="+dbPath,"-gd", "@nte_"+req)
			dataOut = strings.ReplaceAll(dataOut,"\n", "")
	}
	return
}

func processTheme( themeMode string, props []string){
	// bg-color=000000ff
	// Update the theme in database
	for i := 0; i < len(props); i++ {
		prop := strings.Split(props[i], "=")
		config("-set", themeMode+"_"+prop[0]+"="+prop[1])
		goSh(0,"sh","-c",mainPath+"/applyTheme.sh ",themeMode,prop[0],prop[1])
	}

}

func main() {
	// nebula-theme -d accent=#ffffff background=#000000
	args := os.Args
	fmt.Println(strings.Split(config("-list","dark"), "\n"))
	switch args[1] {
		case "--dark","-d":
			processTheme("dark", args[2:])
		case "--light","-l":
			processTheme("light", args[2:])
		default:
			fmt.Print("Nothing to do...")

	}
}
